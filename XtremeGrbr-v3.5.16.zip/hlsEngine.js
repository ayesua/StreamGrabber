/**
 * StreamGrabber - HLS (.m3u8) Downloader Engine
 * Full stream downloader with In-Page Fetch Bridge (Bypasses HTTP 412 / CORS), AES-128 Decryption & Segment Joining
 */

export function saveBlobToDB(key, blob) {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open('StreamGrabberDB', 1);
    req.onupgradeneeded = () => {
      req.result.createObjectStore('blobs');
    };
    req.onsuccess = () => {
      const db = req.result;
      const tx = db.transaction('blobs', 'readwrite');
      tx.objectStore('blobs').put(blob, key);
      tx.oncomplete = () => {
        db.close();
        resolve();
      };
      tx.onerror = () => {
        db.close();
        reject(tx.error);
      };
    };
    req.onerror = () => reject(req.error);
  });
}

export async function ensureOffscreenDocument() {
  if (!chrome.offscreen) return;
  try {
    const existingContexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT']
    });
    if (existingContexts && existingContexts.length > 0) return;
  } catch (e) {}

  try {
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['BLOBS'],
      justification: 'Create Blob URL for video file download'
    });
  } catch (err) {
    if (!err.message?.includes('Only a single offscreen document may be created')) {
      console.warn('[StreamGrabber] Error creating offscreen doc:', err);
    }
  }
}

/**
 * Lossless MP4 Matrix Rotation Utility
 * Modifies the 3x3 transformation matrix in the video track's tkhd box without re-encoding.
 */
export function applyMp4Rotation(arrayBuffer, rotationDegrees) {
  const validAngles = [0, 90, 180, 270];
  const angle = validAngles.includes(rotationDegrees) ? rotationDegrees : 0;
  if (angle === 0 || !arrayBuffer) return arrayBuffer;

  const uint8 = new Uint8Array(arrayBuffer);
  const dataView = new DataView(arrayBuffer);

  function getBoxType(offset) {
    return String.fromCharCode(
      uint8[offset],
      uint8[offset + 1],
      uint8[offset + 2],
      uint8[offset + 3]
    );
  }

  let offset = 0;
  let moovOffset = -1;
  let moovSize = 0;

  // 1. Find 'moov' box
  while (offset + 8 <= uint8.length) {
    let size = dataView.getUint32(offset);
    const type = getBoxType(offset + 4);

    if (size === 1) {
      size = Number(dataView.getBigUint64(offset + 8));
    } else if (size === 0) {
      size = uint8.length - offset;
    }

    if (type === 'moov') {
      moovOffset = offset;
      moovSize = size;
      break;
    }
    offset += size;
  }

  if (moovOffset === -1) {
    return arrayBuffer;
  }

  // 2. Scan inside 'moov' for 'trak' boxes
  let moovEnd = moovOffset + moovSize;
  let trakOffset = moovOffset + 8;

  while (trakOffset + 8 <= moovEnd) {
    let trakSize = dataView.getUint32(trakOffset);
    const trakType = getBoxType(trakOffset + 4);

    if (trakSize === 1) {
      trakSize = Number(dataView.getBigUint64(trakOffset + 8));
    } else if (trakSize === 0) {
      trakSize = moovEnd - trakOffset;
    }

    if (trakType === 'trak') {
      const trakEnd = trakOffset + trakSize;
      let innerOffset = trakOffset + 8;
      let tkhdOffset = -1;

      while (innerOffset + 8 <= trakEnd) {
        let childSize = dataView.getUint32(innerOffset);
        const childType = getBoxType(innerOffset + 4);
        if (childSize === 1) childSize = Number(dataView.getBigUint64(innerOffset + 8));
        else if (childSize === 0) childSize = trakEnd - innerOffset;

        if (childType === 'tkhd') {
          tkhdOffset = innerOffset;
          break;
        }
        innerOffset += childSize;
      }

      if (tkhdOffset !== -1) {
        const version = uint8[tkhdOffset + 8];
        const matrixOffset = tkhdOffset + (version === 1 ? 56 : 44);
        const widthOffset = matrixOffset + 36;
        const width16 = dataView.getUint32(widthOffset);
        const height16 = dataView.getUint32(widthOffset + 4);

        const width = width16 >> 16;
        const height = height16 >> 16;

        const u = 0x00010000;
        const nu = 0xFFFF0000;
        const w = 0x40000000;

        let a = u, b = 0, c = 0, d = u, tx = 0, ty = 0;

        if (angle === 90) {
          a = 0; b = u;
          c = nu; d = 0;
          tx = (height << 16); ty = 0;
        } else if (angle === 180) {
          a = nu; b = 0;
          c = 0; d = nu;
          tx = (width << 16); ty = (height << 16);
        } else if (angle === 270) {
          a = 0; b = nu;
          c = u; d = 0;
          tx = 0; ty = (width << 16);
        }

        dataView.setUint32(matrixOffset, a);
        dataView.setUint32(matrixOffset + 4, b);
        dataView.setUint32(matrixOffset + 8, 0);

        dataView.setUint32(matrixOffset + 12, c);
        dataView.setUint32(matrixOffset + 16, d);
        dataView.setUint32(matrixOffset + 20, 0);

        dataView.setUint32(matrixOffset + 24, tx);
        dataView.setUint32(matrixOffset + 28, ty);
        dataView.setUint32(matrixOffset + 32, w);
      }
    }
    trakOffset += trakSize;
  }

  return arrayBuffer;
}

export class HLSEngine {
  constructor(options = {}) {
    this.maxParallel = options.maxParallel || 8;
    this.activeDownloads = new Map();
    this.keyCache = new Map();
  }

  resolveUrl(relative, base) {
    try {
      return new URL(relative, base).href;
    } catch (e) {
      return relative;
    }
  }

  hexToUint8Array(hexString) {
    const cleaned = hexString.replace(/^0x/i, '');
    const bytes = new Uint8Array(cleaned.length / 2);
    for (let i = 0; i < cleaned.length; i += 2) {
      bytes[i / 2] = parseInt(cleaned.substr(i, 2), 16);
    }
    return bytes;
  }

  seqToIV(seq) {
    const iv = new Uint8Array(16);
    const view = new DataView(iv.buffer);
    view.setUint32(12, seq, false);
    return iv;
  }

  /**
   * Send message to content script with a strict timeout so frozen/ad iframes can never hang downloads.
   */
  sendTabMessageWithTimeout(tabId, message, timeoutMs = 8000) {
    if (!tabId) return Promise.resolve(null);
    return new Promise((resolve) => {
      let settled = false;
      const timer = setTimeout(() => {
        if (!settled) {
          settled = true;
          resolve(null);
        }
      }, timeoutMs);

      try {
        chrome.tabs.sendMessage(tabId, message, (res) => {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          if (chrome.runtime.lastError || !res) {
            resolve(null);
          } else {
            resolve(res);
          }
        });
      } catch (e) {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          resolve(null);
        }
      }
    });
  }

  /**
   * Fetch with AbortController timeout so unresponsive CDNs fail fast and trigger fallback/retry.
   */
  async fetchWithTimeout(url, options = {}, timeoutMs = 12000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await fetch(url, { ...options, signal: controller.signal });
    } finally {
      clearTimeout(timer);
    }
  }

  /**
   * Resilient Text Fetcher: Tries background fetch first (fast, immune to CORS wildcard issues,
   * uses DNR Referer/Origin headers), then falls back to in-page fetch via content script (bypasses HTTP 412).
   */
  async fetchPlaylistText(url, tabId, referer) {
    const headers = {
      'Accept': '*/*'
    };
    if (referer) {
      try {
        headers['Referer'] = referer;
      } catch (e) {}
    }

    let bgError = null;
    // 1. Primary: Background fetch (immune to CORS Access-Control-Allow-Origin: * + credentials issues)
    try {
      const resp = await this.fetchWithTimeout(url, {
        headers,
        cache: 'no-store'
      }, 10000);

      if (resp.ok) {
        const text = await resp.text();
        if (text && text.includes('#EXTM3U')) {
          return text;
        }
      } else {
        bgError = new Error(`HTTP ${resp.status} reading playlist`);
      }
    } catch (e) {
      bgError = e;
    }

    // 2. Fallback: In-Page Fetch (100% immune to HTTP 412 Precondition Failed / strict cookie checks)
    if (tabId) {
      try {
        const response = await this.sendTabMessageWithTimeout(
          tabId,
          { action: 'PAGE_FETCH_TEXT', url, referer },
          8000
        );

        if (response && response.success && response.text) {
          return response.text;
        }
      } catch (e) {}
    }

    throw bgError || new Error('Could not read HLS playlist');
  }

  /**
   * Resilient Segment Buffer Fetcher:
   * 1. Primary: Native background fetch (high-speed ArrayBuffer, immune to CORS wildcard issues, zero Base64 IPC overhead).
   * 2. Fallback: In-Page Fetch via Content Script (for CDNs requiring strict page cookies/TLS session).
   */
  async fetchSegmentBuffer(segUrl, tabId, referer) {
    const headers = {
      'Accept': '*/*'
    };
    if (referer) {
      try {
        headers['Referer'] = referer;
      } catch (e) {}
    }

    // 1. Primary: Background fetch with DNR Referer header & timeout
    try {
      const resp = await this.fetchWithTimeout(segUrl, { headers, cache: 'no-store' }, 20000);
      if (resp.ok) {
        const buf = await resp.arrayBuffer();
        if (buf && buf.byteLength > 0) {
          return buf;
        }
      }
    } catch (e) {}

    // 2. Fallback: In-Page Fetch via Content Script with strict timeout
    if (tabId) {
      try {
        const response = await this.sendTabMessageWithTimeout(
          tabId,
          { action: 'PAGE_FETCH_BUFFER', url: segUrl, referer },
          20000
        );

        if (response && response.success && response.base64) {
          const binary = atob(response.base64);
          const bytes = new Uint8Array(binary.length);
          for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
          }
          return bytes.buffer;
        }
      } catch (e) {}
    }

    throw new Error(`Could not download video segment: ${segUrl}`);
  }

  parseM3U8(content, baseUrl) {
    const lines = content.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    const isMaster = lines.some(line => line.startsWith('#EXT-X-STREAM-INF'));

    if (isMaster) {
      const variants = [];
      let currentVariant = null;

      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (line.startsWith('#EXT-X-STREAM-INF:')) {
          currentVariant = {};
          const resMatch = line.match(/RESOLUTION=(\d+x\d+)/i);
          if (resMatch) currentVariant.resolution = resMatch[1];
          const bwMatch = line.match(/BANDWIDTH=(\d+)/i);
          if (bwMatch) currentVariant.bandwidth = parseInt(bwMatch[1], 10);
          const nameMatch = line.match(/NAME="([^"]+)"/i);
          if (nameMatch) currentVariant.name = nameMatch[1];
        } else if (currentVariant && !line.startsWith('#')) {
          currentVariant.url = this.resolveUrl(line, baseUrl);
          variants.push(currentVariant);
          currentVariant = null;
        }
      }

      // Always sort to select highest quality: resolution first, then bandwidth
      variants.sort((a, b) => {
        const getResHeight = (res) => {
          if (!res) return 0;
          const parts = res.split('x');
          return parts.length > 1 ? parseInt(parts[1], 10) : parseInt(res, 10) || 0;
        };
        const hA = getResHeight(a.resolution);
        const hB = getResHeight(b.resolution);
        if (hA !== hB) return hB - hA;
        return (b.bandwidth || 0) - (a.bandwidth || 0);
      });
      return { isMaster: true, variants };
    } else {
      const segments = [];
      let currentKeyInfo = null;
      let currentSeq = 0;
      let totalDurationSec = 0;
      let initSegmentUrl = null;

      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (line.startsWith('#EXT-X-MAP:')) {
          const mapMatch = line.match(/URI="([^"]+)"/i);
          if (mapMatch) {
            initSegmentUrl = this.resolveUrl(mapMatch[1], baseUrl);
          }
        } else if (line.startsWith('#EXTINF:')) {
          const durMatch = line.match(/#EXTINF:([\d.]+)/);
          if (durMatch) totalDurationSec += parseFloat(durMatch[1]);
        } else if (line.startsWith('#EXT-X-MEDIA-SEQUENCE:')) {
          currentSeq = parseInt(line.split(':')[1], 10) || 0;
        } else if (line.startsWith('#EXT-X-KEY:')) {
          const methodMatch = line.match(/METHOD=([^,\s]+)/);
          const method = methodMatch ? methodMatch[1] : null;

          if (method === 'AES-128') {
            const uriMatch = line.match(/URI="([^"]+)"/);
            const ivMatch = line.match(/IV=([^,\s]+)/);
            if (uriMatch) {
              currentKeyInfo = {
                method: 'AES-128',
                keyUrl: this.resolveUrl(uriMatch[1], baseUrl),
                iv: ivMatch ? this.hexToUint8Array(ivMatch[1]) : null
              };
            }
          } else {
            currentKeyInfo = null;
          }
        } else if (!line.startsWith('#')) {
          segments.push({
            url: this.resolveUrl(line, baseUrl),
            seq: currentSeq,
            keyInfo: currentKeyInfo ? { ...currentKeyInfo, iv: currentKeyInfo.iv || this.seqToIV(currentSeq) } : null
          });
          currentSeq++;
        }
      }

      // Prepend fMP4 init segment (ftyp + moov headers) so video plays cleanly
      if (initSegmentUrl) {
        segments.unshift({
          url: initSegmentUrl,
          seq: -1,
          isInit: true,
          keyInfo: null
        });
      }

      return { isMaster: false, segments, totalDurationSec: Math.round(totalDurationSec) };
    }
  }

  async getCryptoKey(keyUrl, tabId, referer) {
    if (this.keyCache.has(keyUrl)) {
      return this.keyCache.get(keyUrl);
    }

    const rawKey = await this.fetchSegmentBuffer(keyUrl, tabId, referer);
    const cryptoKey = await crypto.subtle.importKey(
      'raw',
      rawKey,
      { name: 'AES-CBC' },
      false,
      ['decrypt']
    );

    this.keyCache.set(keyUrl, cryptoKey);
    return cryptoKey;
  }

  async decryptSegment(encryptedBuffer, keyInfo, tabId, referer) {
    if (!keyInfo) return encryptedBuffer;

    try {
      const cryptoKey = await this.getCryptoKey(keyInfo.keyUrl, tabId, referer);
      const decrypted = await crypto.subtle.decrypt(
        { name: 'AES-CBC', iv: keyInfo.iv },
        cryptoKey,
        encryptedBuffer
      );
      return decrypted;
    } catch (err) {
      console.warn('Fallo en descifrado AES, usando original:', err);
      return encryptedBuffer;
    }
  }

  /**
   * Start complete HLS stream download
   */
  async startDownload({ id, url, selectedVariantUrl, title, tabId, referer, format, saveAs, rotation = 0, onProgress, onStatusChange }) {
    const downloadId = id || 'hls_' + Date.now();
    const targetFormat = (format || 'mp4').toLowerCase();
    
    const downloadState = {
      id: downloadId,
      url,
      selectedVariantUrl,
      title: title || 'full_video',
      format: targetFormat,
      rotation: rotation || 0,
      status: 'analyzing',
      progress: 0,
      downloadedBytes: 0,
      totalSegments: 0,
      completedSegments: 0,
      speedBps: 0,
      cancelRequested: false
    };

    this.activeDownloads.set(downloadId, downloadState);

    const updateState = (updates) => {
      Object.assign(downloadState, updates);
      if (onProgress) onProgress(downloadState);
      if (onStatusChange && updates.status) onStatusChange(downloadState);
    };

    try {
      updateState({ status: 'analyzing' });

      // Target URL: either the user's explicitly selected variant or the master playlist URL
      const streamUrl = selectedVariantUrl || url;
      const initialText = await this.fetchPlaylistText(streamUrl, tabId, referer);
      let parsed = this.parseM3U8(initialText, streamUrl);

      // If it's a Master playlist (and user didn't pick a direct media playlist), select best or chosen variant
      let selectedBandwidth = 0;
      if (parsed.isMaster) {
        if (!parsed.variants || parsed.variants.length === 0) {
          throw new Error('No stream variants found in stream');
        }
        const chosenVariant = (selectedVariantUrl && parsed.variants.find(v => v.url === selectedVariantUrl)) || parsed.variants[0];
        selectedBandwidth = chosenVariant.bandwidth || 0;
        const mediaText = await this.fetchPlaylistText(chosenVariant.url, tabId, referer);
        parsed = this.parseM3U8(mediaText, chosenVariant.url);
      }

      if (!parsed.segments || parsed.segments.length === 0) {
        throw new Error('No video segments found in playlist');
      }

      const segments = parsed.segments;
      downloadState.totalSegments = segments.length;

      // Smart Size & Duration Estimation for UI
      if (parsed.totalDurationSec) {
        downloadState.durationSec = parsed.totalDurationSec;
        if (selectedBandwidth > 0) {
          downloadState.estimatedBytes = Math.round((selectedBandwidth * parsed.totalDurationSec) / 8);
        }
      }

      updateState({
        status: 'downloading',
        progress: Math.max(2, downloadState.progress || 0),
        totalSegments: segments.length,
        durationSec: downloadState.durationSec,
        estimatedBytes: downloadState.estimatedBytes
      });

      const segmentBuffers = new Array(segments.length);
      let loadedCount = 0;
      let totalBytes = 0;
      let lastSpeedCheck = Date.now();
      let bytesSinceCheck = 0;

      const downloadSegment = async (index) => {
        if (downloadState.cancelRequested) return;

        const seg = segments[index];
        let retries = 5;

        while (retries > 0) {
          try {
            let buffer = await this.fetchSegmentBuffer(seg.url, tabId, referer);

            if (seg.keyInfo) {
              buffer = await this.decryptSegment(buffer, seg.keyInfo, tabId, referer);
            }

            segmentBuffers[index] = buffer;
            loadedCount++;
            totalBytes += buffer.byteLength;
            bytesSinceCheck += buffer.byteLength;

            const now = Date.now();
            const elapsedSec = (now - lastSpeedCheck) / 1000;
            if (elapsedSec >= 0.25) {
              downloadState.speedBps = bytesSinceCheck / elapsedSec;
              lastSpeedCheck = now;
              bytesSinceCheck = 0;
            }

            const progress = Math.round((loadedCount / segments.length) * 100);
            updateState({
              progress,
              completedSegments: loadedCount,
              downloadedBytes: totalBytes
            });
            break;
          } catch (err) {
            retries--;
            if (retries === 0) throw new Error(`Error en fragmento ${index + 1}/${segments.length}: ${err.message}`);
            await new Promise(r => setTimeout(r, Math.min(1000, (6 - retries) * 200)));
          }
        }
      };

      // Bulletproof Parallel Worker Queue with shared atomic index
      let nextIndex = 0;
      let downloadError = null;

      const worker = async () => {
        while (nextIndex < segments.length && !downloadState.cancelRequested && !downloadError) {
          const currentIndex = nextIndex++;
          try {
            await downloadSegment(currentIndex);
          } catch (err) {
            console.error(`Segment ${currentIndex} download failed:`, err);
            downloadError = err;
          }
        }
      };

      const numWorkers = Math.min(this.maxParallel || 8, segments.length);
      const workers = [];
      for (let w = 0; w < numWorkers; w++) {
        workers.push(worker());
      }

      await Promise.all(workers);

      if (downloadState.cancelRequested) {
        updateState({ status: 'cancelled' });
        return null;
      }

      if (downloadError) {
        throw downloadError;
      }

      // Verify every segment is a valid, non-empty ArrayBuffer (prevents "undefined" holes and corrupted video)
      const validBuffers = [];
      for (let i = 0; i < segments.length; i++) {
        let buf = segmentBuffers[i];
        if (!buf || !(buf instanceof ArrayBuffer) || buf.byteLength === 0) {
          try {
            await downloadSegment(i);
            buf = segmentBuffers[i];
          } catch (e) {
            throw new Error(`Error: Could not retrieve segment ${i + 1}/${segments.length}`);
          }
        }
        if (buf && buf instanceof ArrayBuffer && buf.byteLength > 0) {
          validBuffers.push(buf);
        } else {
          throw new Error(`Error: Incomplete segment ${i + 1}`);
        }
      }

      updateState({ status: 'merging', progress: 99 });

      // Set MIME type and filename
      let mimeType = 'video/mp4';
      if (targetFormat === 'mkv') mimeType = 'video/x-matroska';
      else if (targetFormat === 'ts') mimeType = 'video/mp2t';

      let finalBlobData = validBuffers;
      if (rotation && rotation !== 0 && targetFormat === 'mp4') {
        let totalLen = 0;
        for (const b of validBuffers) totalLen += b.byteLength;
        const merged = new Uint8Array(totalLen);
        let off = 0;
        for (const b of validBuffers) {
          merged.set(new Uint8Array(b), off);
          off += b.byteLength;
        }
        const rotatedBuffer = applyMp4Rotation(merged.buffer, rotation);
        finalBlobData = [rotatedBuffer];
      }

      const concatenatedBlob = new Blob(finalBlobData, { type: mimeType });
      const sanitizedTitle = (downloadState.title || 'full_video')
        .replace(/[/\\?%*:|"<>]/g, '_')
        .replace(/\s+/g, ' ')
        .trim()
        .substring(0, 100);
      const filename = `${sanitizedTitle}.${targetFormat}`;

      // 1. Primary: Download via Offscreen Document and native ObjectURL (avoids Chrome data: URL limits)
      let downloadedViaOffscreen = false;

      if (chrome.offscreen) {
        try {
          const blobKey = 'hls_' + Date.now();
          await saveBlobToDB(blobKey, concatenatedBlob);
          await ensureOffscreenDocument();

          const createRes = await new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({
              action: 'CREATE_BLOB_URL',
              key: blobKey
            }, (res) => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else if (res && res.success && res.blobUrl) {
                resolve(res);
              } else {
                reject(new Error(res?.error || 'Offscreen Blob URL creation failed'));
              }
            });
          });

          const blobUrl = createRes.blobUrl;
          const downloadItemId = await new Promise((resolve, reject) => {
            chrome.downloads.download({
              url: blobUrl,
              filename: filename,
              saveAs: Boolean(saveAs)
            }, (id) => {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve(id);
              }
            });
          });

          downloadedViaOffscreen = true;
          updateState({ status: 'complete', progress: 100, downloadItemId });
          setTimeout(() => {
            chrome.runtime.sendMessage({ action: 'REVOKE_BLOB_URL', blobUrl }).catch(() => {});
          }, 120000);
          return { downloadItemId, filename, size: concatenatedBlob.size };
        } catch (offErr) {
          console.warn('[StreamGrabber] Offscreen download fallback triggered:', offErr);
        }
      }

      // 2. Direct ObjectURL if running in a window context where URL.createObjectURL is supported
      if (!downloadedViaOffscreen && typeof URL !== 'undefined' && typeof URL.createObjectURL === 'function') {
        const downloadUrl = URL.createObjectURL(concatenatedBlob);
        return new Promise((resolve, reject) => {
          chrome.downloads.download({
            url: downloadUrl,
            filename: filename,
            saveAs: Boolean(saveAs)
          }, (downloadItemId) => {
            if (chrome.runtime.lastError) {
              updateState({ status: 'error', error: chrome.runtime.lastError.message });
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              updateState({ status: 'complete', progress: 100, downloadItemId });
              resolve({ downloadItemId, filename, size: concatenatedBlob.size });
            }
          });
        });
      }

      // 3. Last-resort fallback for tiny files
      const downloadUrl = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = () => reject(new Error('Error processing video file in memory'));
        reader.readAsDataURL(concatenatedBlob);
      });

      return new Promise((resolve, reject) => {
        chrome.downloads.download({
          url: downloadUrl,
          filename: filename,
          saveAs: Boolean(saveAs)
        }, (downloadItemId) => {
          if (chrome.runtime.lastError) {
            updateState({ status: 'error', error: chrome.runtime.lastError.message });
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            updateState({ status: 'complete', progress: 100, downloadItemId });
            resolve({ downloadItemId, filename, size: concatenatedBlob.size });
          }
        });
      });

    } catch (err) {
      updateState({ status: 'error', error: err.message });
      throw err;
    }
  }

  cancelDownload(downloadId) {
    const state = this.activeDownloads.get(downloadId);
    if (state) {
      state.cancelRequested = true;
      state.status = 'cancelled';
    }
  }
}

export const hlsEngine = new HLSEngine();
