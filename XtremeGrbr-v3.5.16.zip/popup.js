/**
 * StreamGrabber - Popup Script
 * Shows static video frame photos, format selector, inline renaming, filter pills, and active download controls
 */

let currentTabId = null;
let currentTabUrl = '';
let currentTabTitle = '';
let currentTabHost = '';
let isCurrentSiteExcluded = false;
let excludedSitesList = [];
let allDetectedMedia = [];
let currentFilter = 'all'; // 'all' | 'video' | 'audio'
let currentLang = 'en';
let isExtensionEnabled = true;

function checkSiteIsExcluded(host, sites) {
  if (!host || !Array.isArray(sites)) return false;
  const h = host.toLowerCase().trim();
  return sites.some(s => {
    const clean = s.toLowerCase().trim();
    return clean && (h === clean || h.endsWith('.' + clean));
  });
}

function formatSpeed(bps) {
  if (!bps || bps <= 0) return '0 KB/s';
  if (bps < 1024 * 1024) return (bps / 1024).toFixed(1) + ' KB/s';
  return (bps / (1024 * 1024)).toFixed(2) + ' MB/s';
}

function formatBytes(bytes) {
  if (!bytes) return '0 MB';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

function isGenericOrTechnicalTitle(title) {
  if (!title) return true;
  const clean = title.toLowerCase().trim();
  if (!clean || clean.length <= 2) return true;

  const genericList = [
    'master', 'index', 'playlist', 'video', 'manifest', 'stream',
    'video_completo', 'video_stream', 'full_video', 'full video',
    'media', 'videoplayback', 'playback', 'output', 'file', 'source',
    'untitled', 'default', 'null', 'undefined', 'movie', 'clip',
    'watch', 'play', 'download', 'streaming'
  ];
  if (genericList.includes(clean)) return true;

  if (/^tpl[-_]?/i.test(clean) || /^tpl\d+/i.test(clean) || clean === 'tpl' || clean.startsWith('tpl')) return true;
  if (/^(hls|dash|seg|segment|chunk|frag|fragment|part)[-_]?\d*/i.test(clean)) return true;
  if (/^(video|stream|track|aud|audio)[-_]?\d+/i.test(clean)) return true;
  if (/^(\d{3,4}p|\d{3,4}x\d{3,4}|mp4|webm|m3u8|ts|m4s)$/i.test(clean)) return true;
  if (/^[0-9a-f]{12,}$/i.test(clean)) return true;

  return false;
}

function updateExtensionStatusUI() {
  const masterPowerToggle = document.getElementById('masterPowerToggle');
  const masterPowerLabel = document.getElementById('masterPowerLabel');
  const btnSubbarToggle = document.getElementById('btnSubbarToggle');
  const btnToggle = document.getElementById('btnToggleExtension');
  const disabledBanner = document.getElementById('disabledBanner');
  const siteExcludedBanner = document.getElementById('siteExcludedBanner');
  const siteExcludedTitle = document.getElementById('siteExcludedTitle');
  const btnExcludeSite = document.getElementById('btnExcludeSite');
  const mediaListContainer = document.getElementById('mediaListContainer');
  const emptyState = document.getElementById('emptyState');
  const filterPills = document.querySelector('.filter-pills-bar');
  const mediaCount = document.getElementById('mediaCount');

  // Handle current site exclusion button in subbar
  if (btnExcludeSite) {
    if (!currentTabHost || currentTabUrl.startsWith('chrome') || currentTabUrl.startsWith('edge') || currentTabUrl.startsWith('about')) {
      btnExcludeSite.style.display = 'none';
    } else {
      btnExcludeSite.style.display = 'inline-flex';
      if (isCurrentSiteExcluded) {
        btnExcludeSite.textContent = '⛔ Excluded';
        btnExcludeSite.className = 'subbar-toggle-pill excluded';
        btnExcludeSite.setAttribute('title', `${currentTabHost} is excluded. Click to re-enable.`);
      } else {
        btnExcludeSite.textContent = '⛔ Exclude Site';
        btnExcludeSite.className = 'subbar-toggle-pill';
        btnExcludeSite.setAttribute('title', `Click to exclude ${currentTabHost} from XtremeGrbr`);
      }
    }
  }

  // Handle site excluded banner
  if (siteExcludedBanner) {
    siteExcludedBanner.style.display = isCurrentSiteExcluded ? 'flex' : 'none';
    if (siteExcludedTitle && currentTabHost) {
      siteExcludedTitle.textContent = `${currentTabHost} Excluded`;
    }
  }

  // If site is excluded, override listing and badge
  if (isCurrentSiteExcluded) {
    if (disabledBanner) disabledBanner.style.display = 'none';
    if (mediaCount) {
      mediaCount.textContent = 'Excluded';
      mediaCount.style.background = '#fef2f2';
      mediaCount.style.color = '#dc2626';
    }
    if (mediaListContainer) mediaListContainer.style.display = 'none';
    if (emptyState) emptyState.style.display = 'none';
    if (filterPills) filterPills.style.opacity = '0.35';
    return;
  }

  // 1. Sync header slider switch & label
  if (masterPowerToggle) {
    masterPowerToggle.checked = isExtensionEnabled;
  }
  if (masterPowerLabel) {
    masterPowerLabel.textContent = isExtensionEnabled ? 'ON' : 'OFF';
    masterPowerLabel.classList.toggle('disabled', !isExtensionEnabled);
  }

  // 2. Sync subbar toggle pill
  if (btnSubbarToggle) {
    btnSubbarToggle.textContent = isExtensionEnabled ? '🟢 Active' : '🔴 Disabled';
    btnSubbarToggle.className = isExtensionEnabled ? 'subbar-toggle-pill enabled' : 'subbar-toggle-pill disabled';
    btnSubbarToggle.setAttribute('title', isExtensionEnabled ? 'Click to disable XtremeGrbr' : 'Click to enable XtremeGrbr');
  }

  // 3. Sync header icon button
  if (btnToggle) {
    if (isExtensionEnabled) {
      btnToggle.classList.remove('disabled');
      btnToggle.setAttribute('title', 'Pause / Disable XtremeGrbr');
      btnToggle.style.color = '#22c55e';
    } else {
      btnToggle.classList.add('disabled');
      btnToggle.setAttribute('title', 'Turn On / Enable XtremeGrbr');
      btnToggle.style.color = '#ef4444';
    }
  }

  // 4. Sync paused banner
  if (disabledBanner) {
    disabledBanner.style.display = isExtensionEnabled ? 'none' : 'flex';
  }

  // 5. Sync media listing and badge state
  if (!isExtensionEnabled) {
    if (mediaCount) {
      mediaCount.textContent = 'Paused';
      mediaCount.style.background = '#fee2e2';
      mediaCount.style.color = '#ef4444';
    }
    if (mediaListContainer) mediaListContainer.style.display = 'none';
    if (emptyState) emptyState.style.display = 'none';
    if (filterPills) filterPills.style.opacity = '0.35';
  } else {
    if (mediaCount) {
      mediaCount.style.background = '#e0f2fe';
      mediaCount.style.color = 'var(--vdh-blue)';
    }
    if (mediaListContainer) mediaListContainer.style.display = 'block';
    if (filterPills) filterPills.style.opacity = '1';
  }
}

function toggleExtensionEnabled(forcedState = null) {
  if (typeof forcedState === 'boolean') {
    isExtensionEnabled = forcedState;
  } else {
    isExtensionEnabled = !isExtensionEnabled;
  }

  chrome.storage.local.set({ extensionEnabled: isExtensionEnabled }, () => {
    chrome.runtime.sendMessage({ action: 'SET_EXTENSION_ENABLED', enabled: isExtensionEnabled }, () => {
      if (chrome.runtime.lastError) {}
    });
    updateExtensionStatusUI();
    if (isExtensionEnabled && !isCurrentSiteExcluded) {
      loadTabMedia();
    }
  });
}

function toggleSiteExclusion(forcedDomain = null) {
  const domain = (forcedDomain || currentTabHost || '').toLowerCase().trim();
  if (!domain) return;

  const targetExcluded = !isCurrentSiteExcluded;
  chrome.runtime.sendMessage({
    action: 'TOGGLE_SITE_EXCLUSION',
    domain,
    exclude: targetExcluded,
    tabId: currentTabId
  }, () => {
    isCurrentSiteExcluded = targetExcluded;
    updateExtensionStatusUI();
    if (!targetExcluded) {
      loadTabMedia();
    }
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  // 0. Initialize Internationalization (i18n) & Theme
  try {
    const ver = chrome.runtime?.getManifest ? chrome.runtime.getManifest().version : '3.5.14';
    const verEl = document.querySelector('.version-label');
    if (verEl) verEl.textContent = `v${ver}`;
  } catch (_) {}

  if (typeof getStoredLanguage === 'function') {
    getStoredLanguage((lang) => {
      currentLang = lang;
      if (typeof applyI18n === 'function') applyI18n(lang);
    });
  }

  function updateThemeButtonIcon(theme) {
    const themeIcon = document.getElementById('themeIcon');
    if (themeIcon) {
      themeIcon.textContent = theme === 'dark' ? '☀️' : '🌙';
    }
  }

  if (typeof getStoredTheme === 'function') {
    getStoredTheme((theme) => {
      if (typeof applyTheme === 'function') applyTheme(theme);
      updateThemeButtonIcon(theme);
    });
  }

  const btnToggleTheme = document.getElementById('btnToggleTheme');
  if (btnToggleTheme) {
    btnToggleTheme.addEventListener('click', () => {
      const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      const newTheme = isDark ? 'light' : 'dark';
      if (typeof setStoredTheme === 'function') {
        setStoredTheme(newTheme, (theme) => {
          if (typeof applyTheme === 'function') applyTheme(theme);
          updateThemeButtonIcon(theme);
        });
      }
    });
  }

  chrome.storage.local.get({ extensionEnabled: true }, (res) => {
    isExtensionEnabled = res.extensionEnabled !== false;
    updateExtensionStatusUI();
  });

  // Attach event listeners for all toggle elements
  const masterPowerToggle = document.getElementById('masterPowerToggle');
  if (masterPowerToggle) {
    masterPowerToggle.addEventListener('change', (e) => {
      toggleExtensionEnabled(e.target.checked);
    });
  }
  const btnSubbarToggle = document.getElementById('btnSubbarToggle');
  if (btnSubbarToggle) {
    btnSubbarToggle.addEventListener('click', () => toggleExtensionEnabled());
  }
  const btnToggleExtension = document.getElementById('btnToggleExtension');
  if (btnToggleExtension) {
    btnToggleExtension.addEventListener('click', () => toggleExtensionEnabled());
  }
  const btnEnableExtension = document.getElementById('btnEnableExtension');
  if (btnEnableExtension) {
    btnEnableExtension.addEventListener('click', () => toggleExtensionEnabled(true));
  }

  // 1. Get Active Tab & detect hostname
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) {
    currentTabId = tab.id;
    currentTabUrl = tab.url || '';
    currentTabTitle = tab.title || tab.url;
    try {
      if (currentTabUrl.includes('://')) {
        currentTabHost = new URL(currentTabUrl).hostname;
      }
    } catch (_) {}
    const titleEl = document.getElementById('currentTabTitle');
    if (titleEl) titleEl.textContent = tab.title || tab.url;

    chrome.storage.local.get({ excludedSites: ['voyeurok.com'] }, (res) => {
      excludedSitesList = Array.isArray(res.excludedSites) ? res.excludedSites : ['voyeurok.com'];
      isCurrentSiteExcluded = checkSiteIsExcluded(currentTabHost, excludedSitesList);
      updateExtensionStatusUI();

      if (!isCurrentSiteExcluded) {
        // Trigger instant DOM media scan on active tab
        try {
          chrome.tabs.sendMessage(currentTabId, { action: 'SCAN_MEDIA_NOW' }, () => {
            if (chrome.runtime.lastError) {}
            loadTabMedia();
          });
        } catch (e) {}

        loadTabMedia();
      }
    });
  }

  // Site exclusion buttons
  const btnExcludeSite = document.getElementById('btnExcludeSite');
  if (btnExcludeSite) {
    btnExcludeSite.addEventListener('click', () => toggleSiteExclusion());
  }
  const btnIncludeSite = document.getElementById('btnIncludeSite');
  if (btnIncludeSite) {
    btnIncludeSite.addEventListener('click', () => toggleSiteExclusion());
  }

  // Quick Win: Filter Pills Bar (Todos | Videos | Audios)
  const pills = document.querySelectorAll('.pill-btn');
  pills.forEach(pill => {
    pill.addEventListener('click', () => {
      pills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      currentFilter = pill.dataset.filter;
      renderMediaList(allDetectedMedia);
    });
  });

  // Navigation Links
  const btnRescan = document.getElementById('btnRescan');
  if (btnRescan) {
    btnRescan.addEventListener('click', () => {
      if (!currentTabId) return;
      btnRescan.classList.add('rotating');
      chrome.tabs.sendMessage(currentTabId, { action: 'SCAN_MEDIA_NOW' }, (res) => {
        if (chrome.runtime.lastError) {
          chrome.scripting.executeScript({
            target: { tabId: currentTabId },
            files: ['content.js']
          }).catch(() => {});
        }
        setTimeout(() => {
          btnRescan.classList.remove('rotating');
          loadTabMedia();
        }, 500);
      });
    });
  }

  const btnToggleVideoControls = document.getElementById('btnToggleVideoControls');
  if (btnToggleVideoControls) {
    btnToggleVideoControls.addEventListener('click', () => {
      if (!currentTabId) return;
      chrome.tabs.sendMessage(currentTabId, { action: 'TOGGLE_VIDEO_CONTROLS' }, (res) => {
        if (chrome.runtime.lastError) {
          chrome.scripting.executeScript({
            target: { tabId: currentTabId },
            files: ['content.js']
          }).then(() => {
            chrome.tabs.sendMessage(currentTabId, { action: 'TOGGLE_VIDEO_CONTROLS' });
          }).catch(() => {});
        }
        btnToggleVideoControls.classList.add('active-toggle');
        setTimeout(() => {
          btnToggleVideoControls.classList.remove('active-toggle');
        }, 1000);
      });
    });
  }

  const btnOpenPremium = document.getElementById('btnOpenPremium');
  if (btnOpenPremium) {
    btnOpenPremium.addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('premium.html') });
    });
  }

  const footerPremiumLink = document.getElementById('footerPremiumLink');
  if (footerPremiumLink) {
    footerPremiumLink.addEventListener('click', (e) => {
      e.preventDefault();
      chrome.tabs.create({ url: chrome.runtime.getURL('premium.html') });
    });
  }

  const btnOpenOptions = document.getElementById('btnOpenOptions');
  if (btnOpenOptions) {
    btnOpenOptions.addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('options.html') });
    });
  }

  // Donation Modal Controls (Ko-fi, PayPal, Crypto)
  const modalDonations = document.getElementById('modalDonations');
  const btnHeaderDonate = document.getElementById('btnHeaderDonate');
  const btnFooterDonate = document.getElementById('btnFooterDonate');
  const modalDonationsBtnClose = document.getElementById('modalDonationsBtnClose');
  const modalDonationsBtnDone = document.getElementById('modalDonationsBtnDone');

  const openDonationsModal = () => {
    if (modalDonations) modalDonations.style.display = 'flex';
  };
  const closeDonationsModal = () => {
    if (modalDonations) modalDonations.style.display = 'none';
  };

  if (btnHeaderDonate) btnHeaderDonate.addEventListener('click', openDonationsModal);
  if (btnFooterDonate) btnFooterDonate.addEventListener('click', openDonationsModal);
  if (modalDonationsBtnClose) modalDonationsBtnClose.addEventListener('click', closeDonationsModal);
  if (modalDonationsBtnDone) modalDonationsBtnDone.addEventListener('click', closeDonationsModal);

  // 1-Click Copy for Crypto Addresses inside modalDonations
  const copyCryptoButtons = document.querySelectorAll('.btn-copy-crypto');
  copyCryptoButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-target');
      const targetEl = document.getElementById(targetId);
      if (targetEl) {
        const addrText = targetEl.textContent.trim();
        navigator.clipboard.writeText(addrText).then(() => {
          const originalText = btn.textContent;
          btn.textContent = typeof t === 'function' ? t('copiedBtn', currentLang) : 'Copied! ✓';
          btn.classList.add('copied');
          setTimeout(() => {
            btn.textContent = originalText;
            btn.classList.remove('copied');
          }, 2000);
        }).catch(() => {});
      }
    });
  });

  // Feedback Controls (Only appears when user clicks Feedback)
  const btnFeedback = document.getElementById('btnFeedback');
  const modalFeedback = document.getElementById('modalFeedback');
  const modalFeedbackBtnClose = document.getElementById('modalFeedbackBtnClose');
  const btnOpenFeedbackEmail = document.getElementById('btnOpenFeedbackEmail');
  const btnCopyFeedbackEmail = document.getElementById('btnCopyFeedbackEmail');

  const openFeedbackMail = () => {
    chrome.tabs.create({ url: 'mailto:ayesua@gmail.com?subject=StreamGrabber%20Feedback%20%26%20Suggestions' });
  };

  if (btnFeedback && modalFeedback) {
    btnFeedback.addEventListener('click', () => {
      modalFeedback.style.display = 'flex';
    });
  }

  if (modalFeedbackBtnClose && modalFeedback) {
    modalFeedbackBtnClose.addEventListener('click', () => {
      modalFeedback.style.display = 'none';
    });
  }

  if (btnOpenFeedbackEmail) {
    btnOpenFeedbackEmail.addEventListener('click', openFeedbackMail);
  }

  if (btnCopyFeedbackEmail) {
    btnCopyFeedbackEmail.addEventListener('click', () => {
      navigator.clipboard.writeText('ayesua@gmail.com');
      btnCopyFeedbackEmail.textContent = '✅ Copied: ayesua@gmail.com';
      setTimeout(() => {
        btnCopyFeedbackEmail.textContent = '📋 Copy Email Address';
      }, 2000);
    });
  }

  // Listen for progress updates from background
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'DOWNLOAD_PROGRESS' || message.action === 'DOWNLOAD_STATUS') {
      updateActiveDownloadUI(message.state);
    } else if (message.action === 'DOWNLOAD_CANCELLED') {
      const el = document.getElementById(`dl_${message.id}`);
      if (el) el.remove();
      loadTabMedia();
    } else if (message.action === 'MEDIA_UPDATED') {
      if (!message.tabId || !currentTabId || message.tabId === currentTabId) {
        loadTabMedia();
      }
    }
  });

  // Video Orientation / Rotation Listeners
  const btnRotateLeft = document.getElementById('btnRotateLeft');
  const btnRotateRight = document.getElementById('btnRotateRight');
  const btnRotate180 = document.getElementById('btnRotate180');
  const btnRotateReset = document.getElementById('btnRotateReset');

  if (btnRotateLeft) {
    btnRotateLeft.addEventListener('click', () => {
      previewRotationAngle = (previewRotationAngle + 270) % 360;
      updatePreviewRotationUI();
    });
  }
  if (btnRotateRight) {
    btnRotateRight.addEventListener('click', () => {
      previewRotationAngle = (previewRotationAngle + 90) % 360;
      updatePreviewRotationUI();
    });
  }
  if (btnRotate180) {
    btnRotate180.addEventListener('click', () => {
      previewRotationAngle = (previewRotationAngle + 180) % 360;
      updatePreviewRotationUI();
    });
  }
  if (btnRotateReset) {
    btnRotateReset.addEventListener('click', () => {
      previewRotationAngle = 0;
      updatePreviewRotationUI();
    });
  }

  const btnQuickRotateOverlay = document.getElementById('btnQuickRotateOverlay');
  if (btnQuickRotateOverlay) {
    btnQuickRotateOverlay.addEventListener('click', (e) => {
      e.stopPropagation();
      previewRotationAngle = (previewRotationAngle + 90) % 360;
      updatePreviewRotationUI();
    });
  }

  // Preview Modal Listeners
  const modalPreview = document.getElementById('modalPreview');
  const modalPreviewBtnClose = document.getElementById('modalPreviewBtnClose');
  const previewBtnDownload = document.getElementById('previewBtnDownload');

  if (modalPreviewBtnClose) {
    modalPreviewBtnClose.addEventListener('click', closePreview);
  }

  if (previewBtnDownload) {
    previewBtnDownload.addEventListener('click', () => {
      if (!activePreviewItem) return;
      const format = document.getElementById('previewFormatSelect')?.value || 'mp4';
      const itemToDownload = { ...activePreviewItem, rotation: previewRotationAngle };
      closePreview();
      triggerDownload(itemToDownload, format, itemToDownload.selectedVariantUrl);
    });
  }

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (modalPreview && modalPreview.style.display !== 'none') {
        closePreview();
      }
    }
  });
});

let currentHlsInstance = null;
let activePreviewItem = null;
let previewRotationAngle = 0;

function updatePreviewRotationUI() {
  const player = document.getElementById('previewPlayer');
  const badge = document.getElementById('previewRotateBadge');
  if (player) {
    if (previewRotationAngle === 90 || previewRotationAngle === 270) {
      player.style.transform = `rotate(${previewRotationAngle}deg) scale(0.75)`;
    } else {
      player.style.transform = `rotate(${previewRotationAngle}deg) scale(1)`;
    }
  }
  if (badge) {
    badge.textContent = previewRotationAngle === 0 ? '0° (Original)' : `${previewRotationAngle}°`;
  }
}

function openPreview(item) {
  activePreviewItem = item;
  previewRotationAngle = item.rotation || 0;
  updatePreviewRotationUI();
  const modal = document.getElementById('modalPreview');
  const player = document.getElementById('previewPlayer');
  const titleEl = document.getElementById('previewTitle');
  const qualityBadge = document.getElementById('previewQualityBadge');
  const typeBadge = document.getElementById('previewTypeBadge');
  const statusMsg = document.getElementById('previewStatusMsg');

  if (!modal || !player) return;

  closePreviewPlayerOnly();

  if (titleEl) titleEl.textContent = item.title || 'Video Preview';
  if (qualityBadge) qualityBadge.textContent = '★ ' + (item.quality || 'Auto HD');
  if (typeBadge) {
    typeBadge.textContent = item.type || 'MP4';
    typeBadge.className = `thumbnail-badge-type tag tag-type-${(item.type || 'mp4').toLowerCase()}`;
  }
  if (statusMsg) statusMsg.style.display = 'none';

  modal.style.display = 'flex';

  const streamUrl = item.selectedVariantUrl || item.url;

  player.onerror = () => {
    const err = player.error;
    console.warn('[XtremeGrbr] Preview error:', err);
    if (statusMsg) {
      statusMsg.innerHTML = 'Preview note: Server restricted direct in-player playback. <br><strong>Click "Download Now" to download the complete HD file directly!</strong>';
      statusMsg.style.display = 'block';
    }
  };

  const startPlayback = (playUrl) => {
    const activeUrl = playUrl || streamUrl;
    if (item.type === 'HLS' || activeUrl.includes('.m3u8')) {
      if (window.Hls && window.Hls.isSupported()) {
        currentHlsInstance = new window.Hls({
          maxBufferLength: 15,
          enableWorker: true
        });
        currentHlsInstance.loadSource(activeUrl);
        currentHlsInstance.attachMedia(player);
        currentHlsInstance.on(window.Hls.Events.MANIFEST_PARSED, () => {
          player.play().catch(() => {});
        });
        currentHlsInstance.on(window.Hls.Events.ERROR, (event, data) => {
          if (data.fatal) {
            if (statusMsg) {
              statusMsg.textContent = 'Preview notice: Direct stream playback requires unrestricted CORS. Full video download remains available!';
              statusMsg.style.display = 'block';
            }
          }
        });
      } else if (player.canPlayType('application/vnd.apple.mpegurl')) {
        player.src = activeUrl;
        player.play().catch(() => {});
      } else {
        if (statusMsg) {
          statusMsg.textContent = 'HLS preview playback not supported natively in this browser.';
          statusMsg.style.display = 'block';
        }
      }
    } else {
      player.src = activeUrl;
      player.play().catch(() => {});
    }
  };

  let playbackStarted = false;
  const safeStartPlayback = (playUrl) => {
    if (playbackStarted) return;
    playbackStarted = true;
    startPlayback(playUrl);
  };

  const timeoutId = setTimeout(() => {
    safeStartPlayback(streamUrl);
  }, 600);

  chrome.runtime.sendMessage({
    action: 'PREPARE_PREVIEW_RULES',
    url: streamUrl,
    pageUrl: item.pageUrl || ''
  }, (resp) => {
    clearTimeout(timeoutId);
    const playUrl = (resp && resp.finalUrl) ? resp.finalUrl : streamUrl;
    safeStartPlayback(playUrl);
  });
}

function closePreviewPlayerOnly() {
  const player = document.getElementById('previewPlayer');
  if (player) {
    player.pause();
    player.removeAttribute('src');
    player.load();
  }
  if (currentHlsInstance) {
    currentHlsInstance.destroy();
    currentHlsInstance = null;
  }
}

function closePreview() {
  closePreviewPlayerOnly();
  const modal = document.getElementById('modalPreview');
  if (modal) modal.style.display = 'none';
  activePreviewItem = null;
}

async function loadTabMedia() {
  try {
    if (!currentTabId) {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab) {
        currentTabId = tab.id;
        currentTabUrl = tab.url || '';
        currentTabTitle = tab.title || tab.url;
        try {
          if (currentTabUrl.includes('://')) currentTabHost = new URL(currentTabUrl).hostname;
        } catch (_) {}
        const titleEl = document.getElementById('currentTabTitle');
        if (titleEl) titleEl.textContent = tab.title || tab.url;
      }
    }
    if (!currentTabId) return;
    if (isCurrentSiteExcluded) {
      updateExtensionStatusUI();
      return;
    }
    if (!isExtensionEnabled) {
      updateExtensionStatusUI();
      return;
    }

    chrome.runtime.sendMessage({ action: 'GET_TAB_MEDIA', tabId: currentTabId }, (response) => {
      if (chrome.runtime.lastError || !response) return;
      if (response.isSiteExcluded) {
        isCurrentSiteExcluded = true;
        updateExtensionStatusUI();
        return;
      }
      const { mediaList, activeDownloads } = response;

      allDetectedMedia = mediaList || [];
      updateFilterCounts(allDetectedMedia);
      renderMediaList(allDetectedMedia);
      renderActiveDownloads(activeDownloads || []);
    });
  } catch (err) {
    console.warn('[XtremeGrbr] Error in loadTabMedia:', err);
  }
}

function updateFilterCounts(mediaList) {
  const total = mediaList.length;
  const audios = mediaList.filter(m => m.type === 'Audio').length;
  const videos = total - audios;

  const countAll = document.getElementById('countAll');
  const countVideos = document.getElementById('countVideos');
  const countAudios = document.getElementById('countAudios');
  const mediaCount = document.getElementById('mediaCount');

  if (countAll) countAll.textContent = total;
  if (countVideos) countVideos.textContent = videos;
  if (countAudios) countAudios.textContent = audios;

  if (mediaCount && isExtensionEnabled) {
    mediaCount.textContent = `${total} detected`;
    mediaCount.style.background = '#e0f2fe';
    mediaCount.style.color = 'var(--vdh-blue)';
  }
}

function groupAndSortMediaList(rawList) {
  if (!rawList || rawList.length === 0) return [];

  // Group items that represent the same video (by pageUrl or base title or poster)
  const groups = new Map();

  rawList.forEach(item => {
    // Generate clean group key
    let key = (item.title || '').toLowerCase().trim();
    if (isGenericOrTechnicalTitle(key)) {
      key = item.poster ? item.poster.split('?')[0] : (item.pageUrl || item.url);
    }

    if (!groups.has(key)) {
      groups.set(key, []);
    }
    groups.get(key).push(item);
  });

  const processedList = [];

  for (const [, items] of groups.entries()) {
    // Sort items in group from largest to smallest size / highest resolution
    items.sort((a, b) => {
      const sizeA = a.size || a.estimatedBytes || 0;
      const sizeB = b.size || b.estimatedBytes || 0;
      if (sizeA !== sizeB) return sizeB - sizeA;

      const resHeightA = parseInt((a.quality || '').match(/(\d{3,4})/)?.[1] || '0', 10);
      const resHeightB = parseInt((b.quality || '').match(/(\d{3,4})/)?.[1] || '0', 10);
      return resHeightB - resHeightA;
    });

    const primaryItem = { ...items[0] };

    // If multiple resolution/quality variants exist for the same video, merge them into dropdown variants
    if (items.length > 1) {
      const variantList = [];
      items.forEach(it => {
        if (it.variants && it.variants.length > 0) {
          it.variants.forEach(v => variantList.push(v));
        } else {
          variantList.push({
            url: it.url,
            resolution: it.quality || 'Auto HD',
            name: (it.quality || 'Option') + (it.sizeFormatted ? ` (${it.sizeFormatted})` : '')
          });
        }
      });

      // Deduplicate variant URLs
      const uniqueVariants = [];
      const seenVariantUrls = new Set();
      variantList.forEach(v => {
        if (!seenVariantUrls.has(v.url)) {
          seenVariantUrls.add(v.url);
          uniqueVariants.push(v);
        }
      });

      if (uniqueVariants.length > 1) {
        primaryItem.variants = uniqueVariants;
      }
    }

    processedList.push(primaryItem);
  }

  // Sort overall media list from LARGEST file size to SMALLEST
  processedList.sort((a, b) => {
    if (a.type === 'HLS' && b.type !== 'HLS') return -1;
    if (b.type === 'HLS' && a.type !== 'HLS') return 1;

    const sizeA = a.size || a.estimatedBytes || 0;
    const sizeB = b.size || b.estimatedBytes || 0;
    if (sizeA !== sizeB) return sizeB - sizeA;

    const resA = parseInt((a.quality || '').match(/(\d{3,4})/)?.[1] || '0', 10);
    const resB = parseInt((b.quality || '').match(/(\d{3,4})/)?.[1] || '0', 10);
    return resB - resA;
  });

  return processedList;
}

function renderMediaList(mediaList) {
  const container = document.getElementById('mediaListContainer');
  const emptyState = document.getElementById('emptyState');
  const countBadge = document.getElementById('mediaCount');

  // Filter based on active pill
  let filtered = mediaList;
  if (currentFilter === 'video') {
    filtered = mediaList.filter(m => m.type !== 'Audio');
  } else if (currentFilter === 'audio') {
    filtered = mediaList.filter(m => m.type === 'Audio');
  }

  // Deduplicate identical videos into resolution dropdown & sort largest to smallest
  filtered = groupAndSortMediaList(filtered);

  const countText = typeof t === 'function' ? t('detectedCount', currentLang) : 'detected';
  countBadge.textContent = `${filtered.length} ${countText}`;

  if (filtered.length === 0) {
    container.innerHTML = '';
    emptyState.style.display = 'flex';
    return;
  }

  emptyState.style.display = 'none';
  container.innerHTML = filtered.map(item => createMediaCardHTML(item)).join('');

  // Attach button and inline rename event listeners
  filtered.forEach(item => {
    const card = document.getElementById(`card_${item.id}`);
    if (!card) return;

    // Quick Win: Inline Title Editing
    const btnEdit = card.querySelector('.btn-icon-rename');
    const titleRow = card.querySelector('.media-title-row');
    const editWrap = card.querySelector('.media-title-edit-wrap');
    const inputTitle = card.querySelector('.title-edit-input');
    const btnSave = card.querySelector('.btn-icon-save');
    const titleDisplay = card.querySelector('.media-title');

    const saveNewTitle = () => {
      if (!inputTitle) return;
      const newTitle = inputTitle.value.trim();
      if (newTitle) {
        item.title = newTitle;
        if (titleDisplay) {
          titleDisplay.textContent = newTitle;
          titleDisplay.title = newTitle;
        }
      }
      if (titleRow) titleRow.style.display = 'flex';
      if (editWrap) editWrap.style.display = 'none';
    };

    if (btnEdit) {
      btnEdit.addEventListener('click', () => {
        if (titleRow) titleRow.style.display = 'none';
        if (editWrap) {
          editWrap.style.display = 'flex';
          inputTitle.focus();
          inputTitle.select();
        }
      });
    }

    if (btnSave) {
      btnSave.addEventListener('click', saveNewTitle);
    }

    if (inputTitle) {
      inputTitle.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') saveNewTitle();
        if (e.key === 'Escape') {
          if (titleRow) titleRow.style.display = 'flex';
          if (editWrap) editWrap.style.display = 'none';
        }
      });
    }

    // Preview trigger on thumbnail click
    const thumbFrame = card.querySelector('.btn-trigger-preview');
    if (thumbFrame) {
      thumbFrame.addEventListener('click', () => openPreview(item));
    }

    // Preview button
    const btnPreview = card.querySelector('.btn-preview');
    if (btnPreview) {
      btnPreview.addEventListener('click', () => openPreview(item));
    }

    // Quality selector change
    const qualitySelect = card.querySelector('.quality-select');
    if (qualitySelect) {
      qualitySelect.addEventListener('change', (e) => {
        item.selectedVariantUrl = e.target.value;
      });
    }

    // Download Button
    const btnDownload = card.querySelector('.btn-download');
    if (btnDownload) {
      btnDownload.addEventListener('click', () => {
        const format = card.querySelector('.format-select')?.value || 'mp4';
        const selectedVariant = card.querySelector('.quality-select')?.value || item.selectedVariantUrl;
        
        btnDownload.classList.add('is-starting');
        const origDownloadHTML = btnDownload.innerHTML;
        btnDownload.innerHTML = `<span>⏳ ${typeof t === 'function' ? t('startingDownload', currentLang) : 'Starting...'}</span>`;
        setTimeout(() => {
          btnDownload.classList.remove('is-starting');
          btnDownload.innerHTML = origDownloadHTML;
        }, 2200);

        triggerDownload(item, format, selectedVariant);
      });
    }

    // Audio MP3 Button
    const btnAudio = card.querySelector('.btn-audio');
    if (btnAudio) {
      btnAudio.addEventListener('click', () => {
        btnAudio.classList.add('is-starting');
        const origAudioHTML = btnAudio.innerHTML;
        btnAudio.textContent = '⏳ ...';
        setTimeout(() => {
          btnAudio.classList.remove('is-starting');
          btnAudio.innerHTML = origAudioHTML;
        }, 2200);

        triggerDownload({ ...item, type: 'Audio' }, 'mp3');
      });
    }

    // Copy Link Button
    const btnCopy = card.querySelector('.btn-copy');
    if (btnCopy) {
      btnCopy.addEventListener('click', () => {
        navigator.clipboard.writeText(item.url);
        btnCopy.textContent = 'Copied!';
        setTimeout(() => { btnCopy.textContent = 'Copy'; }, 1500);
      });
    }
  });
}

function createMediaCardHTML(item) {
  if (!item.id) item.id = 'media_' + Math.random().toString(36).substr(2, 9);
  const typeClass = item.type ? `tag-type-${item.type.toLowerCase()}` : 'tag-type-mp4';
  
  // Quick Win: Smart Size & Estimation
  let sizeText = item.sizeFormatted;
  if (!sizeText || sizeText === 'Video Completo' || sizeText === 'Full Video') {
    if (item.size) sizeText = formatBytes(item.size);
    else if (item.estimatedBytes) sizeText = '~' + formatBytes(item.estimatedBytes);
    else sizeText = 'Full Video';
  }

  const qualityText = item.quality || 'Auto HD';

  // Video Screenshot Image with seamless fallback
  const hasPoster = Boolean(item.poster);
  const posterImgHTML = hasPoster
    ? `<img src="${escapeHtml(item.poster)}" referrerpolicy="no-referrer" class="media-thumbnail-img" alt="Video frame" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" />`
    : '';

  const placeholderHTML = `
    <div class="thumbnail-placeholder" style="${hasPoster ? 'display:none;' : ''}">
      <div class="camera-frame-icon">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polygon points="23 7 16 12 23 17 23 7"/>
          <rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>
        </svg>
      </div>
      <span style="font-size: 11px; color: #94a3b8; font-weight: 500;">Video Frame</span>
    </div>
  `;

  let cleanTitle = item.title;
  if (isGenericOrTechnicalTitle(cleanTitle)) {
    if (currentTabTitle && !isGenericOrTechnicalTitle(currentTabTitle)) {
      cleanTitle = currentTabTitle;
    } else {
      const goodItem = allDetectedMedia.find(m => m.title && !isGenericOrTechnicalTitle(m.title));
      cleanTitle = goodItem ? goodItem.title : 'Video';
    }
  }

  const qualitySelectHTML = (item.variants && item.variants.length > 1) ? `
    <div class="media-quality-row">
      <span class="quality-label">Resolution:</span>
      <select class="quality-select" title="Choose stream resolution">
        ${item.variants.map((v, idx) => {
          const resHeight = v.resolution ? (v.resolution.split('x')[1] ? v.resolution.split('x')[1] + 'p' : v.resolution) : (v.name || 'Stream');
          const mbps = v.bandwidth ? ` (~${(v.bandwidth / 1000000).toFixed(1)} Mbps)` : '';
          const isSelected = item.selectedVariantUrl ? (item.selectedVariantUrl === v.url) : (idx === 0);
          return `<option value="${escapeHtml(v.url)}" ${isSelected ? 'selected' : ''}>★ ${resHeight}${mbps}</option>`;
        }).join('')}
      </select>
    </div>
  ` : '';

  return `
    <div class="media-card" id="card_${item.id}">
      
      <!-- Static Video Screenshot Photo with Play Overlay -->
      <div class="media-thumbnail-frame btn-trigger-preview" title="Click to preview / rotate video">
        ${posterImgHTML}
        ${placeholderHTML}
        <div class="thumb-play-overlay">
          <div class="thumb-play-circle">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="#ffffff">
              <polygon points="5 3 19 12 5 21 5 3"/>
            </svg>
          </div>
          <span class="thumb-preview-label">${typeof t === 'function' ? t('btnPreview', currentLang) : 'Preview'} / ${typeof t === 'function' ? t('btnRotate', currentLang) : 'Rotate'}</span>
        </div>
        <span class="thumbnail-badge-type tag ${typeClass}">${item.type}</span>
        <span class="thumbnail-badge-res">★ ${qualityText}</span>
      </div>

      <!-- Card Details & Actions -->
      <div class="card-body">
        
        <!-- Inline Title & Rename Button (Quick Win: Editable Title) -->
        <div class="media-title-row">
          <div class="media-title" title="${escapeHtml(cleanTitle)}">${escapeHtml(cleanTitle)}</div>
          <button class="btn-icon-rename" title="Rename file before download">✏️</button>
        </div>
        <div class="media-title-edit-wrap" style="display: none;">
          <input type="text" class="title-edit-input" value="${escapeHtml(cleanTitle)}" />
          <button class="btn-icon-save" title="Save">✓</button>
        </div>

        <div class="media-meta-row">
          <span>Type: <strong>${item.type}</strong></span>
          <span>Size: <strong>${sizeText}</strong></span>
        </div>

        <!-- HLS Stream Quality / Resolution Selector -->
        ${qualitySelectHTML}

        <!-- Download Action Buttons with Format Selector and Preview Button -->
        <div class="media-actions">
          <select class="format-select" title="Select video format (MP4, MKV, TS)">
            <option value="mp4" selected>MP4</option>
            <option value="mkv">MKV</option>
            <option value="ts">TS</option>
          </select>

          <button class="btn-primary btn-download" title="${typeof t === 'function' ? t('btnDownload', currentLang) : 'Download'}">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
            ${typeof t === 'function' ? t('btnDownload', currentLang) : 'Download'}
          </button>

          <button class="btn-secondary btn-preview" title="${typeof t === 'function' ? t('btnPreview', currentLang) : 'Preview'}">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;">
              <path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/>
            </svg>
            <span>${typeof t === 'function' ? t('btnPreview', currentLang) : 'Preview'}</span>
          </button>

          <button class="btn-secondary btn-audio" title="Download as MP3 audio">
            🎵 MP3
          </button>
          
          <button class="btn-secondary btn-copy" title="${typeof t === 'function' ? t('btnCopyUrl', currentLang) : 'Copy direct link'}">
            ${typeof t === 'function' ? t('btnCopyUrl', currentLang) : 'Copy'}
          </button>
        </div>
      </div>

    </div>
  `;
}

function promptForFilename(defaultTitle, callback) {
  const modal = document.getElementById('modalFilename');
  const input = document.getElementById('modalInputFilename');
  const btnConfirm = document.getElementById('modalBtnConfirm');
  const btnCancel = document.getElementById('modalBtnCancel');

  if (!modal || !input || !btnConfirm || !btnCancel) {
    callback(defaultTitle);
    return;
  }

  input.value = defaultTitle;
  modal.style.display = 'flex';

  setTimeout(() => {
    input.focus();
    input.select();
  }, 60);

  const cleanup = () => {
    modal.style.display = 'none';
    btnConfirm.onclick = null;
    btnCancel.onclick = null;
    input.onkeydown = null;
    modal.onclick = null;
  };

  modal.onclick = (e) => {
    if (e.target === modal) {
      cleanup();
      callback(null);
    }
  };

  btnConfirm.onclick = () => {
    const val = input.value.trim() || defaultTitle;
    cleanup();
    callback(val);
  };

  btnCancel.onclick = () => {
    cleanup();
    callback(null); // Cancelled by user
  };

  input.onkeydown = (e) => {
    if (e.key === 'Enter') {
      const val = input.value.trim() || defaultTitle;
      cleanup();
      callback(val);
    } else if (e.key === 'Escape') {
      cleanup();
      callback(null);
    }
  };
}

function triggerDownload(item, format = 'mp4', selectedVariantUrl = null) {
  let finalTitle = item.title;
  if (isGenericOrTechnicalTitle(finalTitle)) {
    if (currentTabTitle && !isGenericOrTechnicalTitle(currentTabTitle)) {
      finalTitle = currentTabTitle;
    } else {
      const goodItem = allDetectedMedia.find(m => m.title && !isGenericOrTechnicalTitle(m.title));
      finalTitle = goodItem ? goodItem.title : 'Video';
    }
  }

  const updatedItem = {
    ...item,
    selectedVariantUrl: selectedVariantUrl || item.selectedVariantUrl || null
  };

  chrome.storage.sync.get({ askFilename: false }, (res) => {
    if (res && res.askFilename) {
      promptForFilename(finalTitle, (chosenTitle) => {
        if (chosenTitle === null) {
          // User clicked Cancel in the modal
          return;
        }
        executeDownload(updatedItem, chosenTitle, format, true);
      });
    } else {
      executeDownload(updatedItem, finalTitle, format, false);
    }
  });
}

function executeDownload(item, title, format, skipSaveAsPrompt = false) {
  const updatedItem = {
    ...item,
    title,
    customTitle: title
  };

  const downloadId = 'dl_' + Date.now();

  // Instant optimistic UI feedback - download card appears immediately!
  updateActiveDownloadUI({
    id: downloadId,
    title: title || item.title || 'Video',
    type: item.type || 'MP4',
    format: format,
    progress: 1,
    speedBps: 0,
    status: 'connecting',
    downloadedBytes: 0
  });

  chrome.runtime.sendMessage({
    action: 'START_DOWNLOAD',
    downloadId,
    item: updatedItem,
    format,
    tabId: currentTabId,
    referer: currentTabUrl,
    skipSaveAsPrompt: Boolean(skipSaveAsPrompt)
  }, (response) => {
    if (chrome.runtime.lastError) return;
    if (response && response.success) {
      loadTabMedia();
    } else if (response && response.error) {
      alert(`Error starting download: ${response.error}`);
    }
  });
}

function renderActiveDownloads(downloads) {
  const container = document.getElementById('activeDownloadsContainer');
  const list = document.getElementById('activeDownloadsList');
  if (!container || !list) return;

  const now = Date.now();
  // Filter out downloads that completed more than 2.5s ago
  const activeOnly = (downloads || []).filter(dl => {
    if (dl.status === 'complete' && dl.completedAt && (now - dl.completedAt > 2500)) {
      return false;
    }
    return true;
  });

  if (activeOnly.length === 0) {
    container.style.display = 'none';
    list.innerHTML = '';
    return;
  }

  container.style.display = 'block';
  list.innerHTML = activeOnly.map(dl => {
    const isComplete = dl.status === 'complete' || (dl.progress >= 100 && dl.status !== 'downloading');
    const isError = dl.status === 'error';
    const isCancelled = dl.status === 'cancelled';
    const isConnecting = !isComplete && !isError && !isCancelled && (
      dl.status === 'connecting' ||
      dl.status === 'starting' ||
      dl.status === 'analyzing' ||
      (dl.progress <= 1 && (!dl.speedBps || dl.speedBps === 0) && !dl.totalSegments)
    );
    return `
      <div class="download-item" id="dl_${dl.id}">
        <div class="download-item-header">
          <div class="download-title">${escapeHtml(dl.title || 'Downloading video...')}</div>
          ${isComplete
            ? '<span style="color: var(--vdh-green); font-size: 11px; font-weight: 700;">✓ Saved</span>'
            : `<button class="btn-cancel-dl" data-id="${dl.id}" title="Cancel download">✕ Cancel</button>`
          }
        </div>
        <div class="progress-bar-bg">
          <div class="progress-bar-fill ${isConnecting ? 'is-connecting' : ''}" style="width: ${isConnecting ? 10 : (dl.progress || 0)}%; ${isComplete ? 'background: var(--vdh-green);' : isError ? 'background: var(--vdh-red);' : ''}"></div>
        </div>
        <div class="download-meta">
          ${isComplete
            ? `<span style="color: var(--vdh-green); font-weight: 700;">Download complete! (100% • ${formatBytes(dl.downloadedBytes)})</span>`
            : isError
              ? `<span style="color: var(--vdh-red);">Error: ${escapeHtml(dl.error || 'Download failed')}</span>`
              : isCancelled
                ? `<span style="color: var(--vdh-text-muted);">Download cancelled</span>`
                : isConnecting
                  ? `<span>⏳ ${typeof t === 'function' ? t('connectingStream', currentLang) : 'Connecting to stream...'}</span><span>⚡ ${typeof t === 'function' ? t('startingDownload', currentLang) : 'Starting...'}</span>`
                  : `<span>${dl.progress || 0}% (${formatBytes(dl.downloadedBytes)})</span><span>⚡ ${formatSpeed(dl.speedBps)}</span>`
          }
        </div>
      </div>
    `;
  }).join('');

  // Auto-remove completed or failed items after a delay
  activeOnly.forEach(dl => {
    if (dl.status === 'complete' || (dl.progress >= 100 && dl.status !== 'downloading')) {
      setTimeout(() => {
        const itemEl = document.getElementById(`dl_${dl.id}`);
        if (itemEl) itemEl.remove();
        if (list.children.length === 0) container.style.display = 'none';
      }, 2500);
    } else if (dl.status === 'error' || dl.status === 'cancelled') {
      setTimeout(() => {
        const itemEl = document.getElementById(`dl_${dl.id}`);
        if (itemEl) itemEl.remove();
        if (list.children.length === 0) container.style.display = 'none';
      }, 5000);
    }
  });

  // Attach cancel download listeners
  list.querySelectorAll('.btn-cancel-dl').forEach(btn => {
    btn.addEventListener('click', () => {
      const dlId = btn.dataset.id;
      chrome.runtime.sendMessage({ action: 'CANCEL_DOWNLOAD', downloadId: dlId }, () => {
        if (chrome.runtime.lastError) return;
        const itemEl = document.getElementById(`dl_${dlId}`);
        if (itemEl) itemEl.remove();
        if (list.children.length === 0) container.style.display = 'none';
        loadTabMedia();
      });
    });
  });
}

function updateActiveDownloadUI(state) {
  if (!state) return;
  const container = document.getElementById('activeDownloadsContainer');
  const list = document.getElementById('activeDownloadsList');
  if (!container || !list) return;

  container.style.display = 'block';

  let el = document.getElementById(`dl_${state.id}`);
  if (!el) {
    const itemDiv = document.createElement('div');
    itemDiv.className = 'download-item';
    itemDiv.id = `dl_${state.id}`;
    itemDiv.innerHTML = `
      <div class="download-item-header">
        <div class="download-title">${escapeHtml(state.title || 'Downloading full video...')}</div>
        <button class="btn-cancel-dl" data-id="${state.id}" title="Cancel download">✕ Cancel</button>
      </div>
      <div class="progress-bar-bg">
        <div class="progress-bar-fill" style="width: ${state.progress || 0}%"></div>
      </div>
      <div class="download-meta">
        <span>${state.progress || 0}% (${formatBytes(state.downloadedBytes)})</span>
        <span>⚡ ${formatSpeed(state.speedBps)}</span>
      </div>
    `;

    const cancelBtn = itemDiv.querySelector('.btn-cancel-dl');
    if (cancelBtn) {
      cancelBtn.addEventListener('click', () => {
        chrome.runtime.sendMessage({ action: 'CANCEL_DOWNLOAD', downloadId: state.id }, () => {
          if (chrome.runtime.lastError) return;
          itemDiv.remove();
          loadTabMedia();
        });
      });
    }

    list.appendChild(itemDiv);
    el = itemDiv;
  }

  const fill = el.querySelector('.progress-bar-fill');
  const meta = el.querySelector('.download-meta');
  const isError = state.status === 'error';
  const isCancelled = state.status === 'cancelled';
  const isComplete = state.status === 'complete';
  const isConnecting = !isComplete && !isError && !isCancelled && (
    state.status === 'connecting' ||
    state.status === 'starting' ||
    state.status === 'analyzing' ||
    (state.progress <= 1 && (!state.speedBps || state.speedBps === 0) && !state.totalSegments)
  );

  if (fill) {
    if (isConnecting) {
      fill.classList.add('is-connecting');
      fill.style.width = '10%';
    } else {
      fill.classList.remove('is-connecting');
      fill.style.width = `${state.progress || 0}%`;
      if (isError) fill.style.background = 'var(--vdh-red)';
    }
  }

  if (meta) {
    if (state.status === 'complete') {
      if (fill) {
        fill.classList.remove('is-connecting');
        fill.style.width = '100%';
        fill.style.background = 'var(--vdh-green)';
      }
      const cancelBtn = el.querySelector('.btn-cancel-dl');
      if (cancelBtn) cancelBtn.outerHTML = '<span style="color: var(--vdh-green); font-size: 11px; font-weight: 700;">✓ Saved</span>';
      meta.innerHTML = `<span style="color: var(--vdh-green); font-weight: bold;">Download complete! (100% • ${formatBytes(state.downloadedBytes)})</span>`;
      setTimeout(() => {
        el.remove();
        if (list.children.length === 0) container.style.display = 'none';
        loadTabMedia();
      }, 2500);
    } else if (state.status === 'cancelled') {
      meta.innerHTML = `<span style="color: var(--vdh-text-muted);">Download cancelled</span>`;
      setTimeout(() => {
        el.remove();
        if (list.children.length === 0) container.style.display = 'none';
      }, 1500);
    } else if (state.status === 'error') {
      meta.innerHTML = `<span style="color: var(--vdh-red);">Error: ${escapeHtml(state.error || 'Streaming error')}</span>`;
    } else if (isConnecting) {
      meta.innerHTML = `
        <span>⏳ ${typeof t === 'function' ? t('connectingStream', currentLang) : 'Connecting to stream...'}</span>
        <span>⚡ ${typeof t === 'function' ? t('startingDownload', currentLang) : 'Starting...'}</span>
      `;
    } else {
      meta.innerHTML = `
        <span>${state.progress || 0}% (${formatBytes(state.downloadedBytes)})</span>
        <span>⚡ ${formatSpeed(state.speedBps)}</span>
      `;
    }
  }
}

// Live listener for download progress and completion events
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === 'DOWNLOAD_PROGRESS' || message.action === 'DOWNLOAD_STATUS') {
    updateActiveDownloadUI(message.state);
  }
});

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
