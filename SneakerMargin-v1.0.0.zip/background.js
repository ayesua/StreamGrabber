/**
 * SneakerMargin Calculator - Background Service Worker
 */

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'FETCH_ARBITRAGE_DATA') {
    const { sku, condition, localPrice, localCurrency, host } = request.payload;
    
    // Fetch user preferences before proceeding
    chrome.storage.local.get({
        targetRoi: 20,
        stockxLevel: '1',
        goatFee: '9.5',
        exchangeRate: 19.5,
        discordWebhook: ''
    }, (settings) => {
        fetchArbitrageData(sku, condition, localPrice, host, localCurrency, settings)
          .then(sendResponse)
          .catch(err => {
            console.error(err);
            sendResponse({ error: err.message });
          });
    });
    
    return true; 
  }
});

async function fetchArbitrageData(sku, condition, localPrice, host, localCurrency, settings) {
  let stockxAsk = null;
  let kickscrewAsk = null;
  let goatPrice = null;
  let isGoatLive = false;
  
  // Rate used if local currency is MXN
  const exchangeRate = parseFloat(settings.exchangeRate) || 19.5;

  const toUsd = (amount, curr) => {
    if (!amount) return null;
    if (curr === 'MXN') return amount / exchangeRate;
    return amount; // already USD
  };

  if (host.includes('goat.com') && localPrice) {
      // GOAT natively operates in USD
      goatPrice = localPrice;
      isGoatLive = true;
      stockxAsk = goatPrice * 0.95;
      kickscrewAsk = goatPrice * 1.10;
  } else if (host.includes('stockx.com') && localPrice) {
      // StockX may be MXN or USD
      stockxAsk = toUsd(localPrice, localCurrency);
      kickscrewAsk = stockxAsk * 1.12; 
  } else if (host.includes('kickscrew.com') && localPrice) {
      // Kickscrew may be MXN (/en-MX/) or USD
      kickscrewAsk = toUsd(localPrice, localCurrency);
      stockxAsk = kickscrewAsk * 0.90; 
  } else {
      stockxAsk = 240; 
      kickscrewAsk = 268.80;
  }

  if (!goatPrice) {
      try {
          goatPrice = await fetchGoatAlgolia(sku, condition);
          if (goatPrice) isGoatLive = true;
      } catch (e) {
          console.warn("GOAT API failed or blocked, falling back to dynamic mock", e);
      }
  }

  if (!goatPrice) {
      goatPrice = condition === 'used' ? stockxAsk * 0.85 : stockxAsk * 1.05;
  }
  
  return {
    sku,
    condition,
    settings, // Pass settings to content script for ROI math and webhooks
    isGoatLive,
    prices: {
      stockx: stockxAsk,
      goat: goatPrice,
      kickscrew: kickscrewAsk
    },
    fees: {
      stockx: stockxAsk ? calculatePayout(stockxAsk, 'stockx', settings) : 0,
      goat: goatPrice ? calculatePayout(goatPrice, 'goat', settings) : 0,
      kickscrew: kickscrewAsk ? calculatePayout(kickscrewAsk, 'kickscrew', settings) : 0
    }
  };
}

async function fetchGoatAlgolia(sku, condition) {
    const appId = '2FWOTDVM2O';
    const apiKey = 'ac96de6fef0e02bb95d433d8d5c7038a'; 
    const url = `https://${appId}-dsn.algolia.net/1/indexes/product_variants_v2/query?x-algolia-agent=Algolia%20for%20JavaScript%20(3.35.1)%3B%20Browser&x-algolia-application-id=${appId}&x-algolia-api-key=${apiKey}`;

    const body = { params: `query=${sku}&hitsPerPage=1&facetFilters=()` };

    const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: JSON.stringify(body)
    });

    if (!res.ok) throw new Error("GOAT Algolia Blocked");
    
    const data = await res.json();
    if (data && data.hits && data.hits.length > 0) {
        const hit = data.hits[0];
        if (condition === 'new' && hit.lowest_price_cents) return hit.lowest_price_cents / 100;
        else if (condition === 'used' && hit.lowest_used_price_cents) return hit.lowest_used_price_cents / 100;
    }
    return null;
}

function calculatePayout(salePrice, platform, settings) {
  let payout = 0;
  if (platform === 'stockx') {
    // Determine fee based on StockX Level
    const levels = { '1': 0.09, '2': 0.085, '3': 0.08, '4': 0.075, '5': 0.07 };
    const feeRate = levels[settings.stockxLevel] || 0.09;
    const fee = (salePrice * feeRate) + (salePrice * 0.03); // base fee + 3% payment proc
    payout = salePrice - fee;
  } else if (platform === 'goat') {
    // Use dynamic GOAT fee
    const feeRate = parseFloat(settings.goatFee) / 100;
    const fee = (salePrice * feeRate) + 5;
    const preCashout = salePrice - fee;
    payout = preCashout - (preCashout * 0.029); // 2.9% cash out fee
  } else if (platform === 'kickscrew') {
    payout = salePrice - (salePrice * 0.08); 
  }
  return Number(payout.toFixed(2));
}
