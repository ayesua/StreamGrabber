/**
 * SneakerMargin - Content Script (Hardened & Polished)
 */

class ArbitrageUI {
  constructor() {
    this.container = document.createElement('div');
    this.container.id = 'sneaker-arbitrage-root';
    this.shadow = this.container.attachShadow({ mode: 'open' });
    
    const style = document.createElement('link');
    style.rel = 'stylesheet';
    style.href = chrome.runtime.getURL('dist/styles.css');
    this.shadow.appendChild(style);

    this.uiWrapper = document.createElement('div');
    this.shadow.appendChild(this.uiWrapper);

    document.body.appendChild(this.container);

    this.isMinimized = false;
    this.currentCondition = 'new'; 
    this.currentSku = extractSKU();
    this.localPrice = extractLocalPrice();
    this.localCurrency = extractCurrency();
    this.salesVelocity = extractVelocity();
  }

  fetchAndRender() {
    if (!this.isMinimized) {
      this.renderLoading();
    }
    chrome.runtime.sendMessage({ 
      type: 'FETCH_ARBITRAGE_DATA', 
      payload: { 
        sku: this.currentSku, 
        condition: this.currentCondition,
        localPrice: this.localPrice,
        localCurrency: this.localCurrency,
        host: window.location.hostname
      } 
    }, (response) => {
      this.renderData(response);
    });
  }

  renderLoading() {
    this.uiWrapper.innerHTML = `
      <div class="fixed bottom-6 right-6 z-[999999] w-80 bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden font-sans transition-all duration-300">
        <div class="p-4 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
          <div class="flex items-center gap-2">
            <div class="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></div>
            <h3 class="font-bold text-sm text-slate-800 dark:text-white">SneakerMargin</h3>
          </div>
          ${this.renderToggle()}
        </div>
        <div class="p-6 flex justify-center items-center">
          <div class="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      </div>
    `;
    this.attachToggleListener();
  }

  renderData(data) {
    if (!data || data.error) {
      this.uiWrapper.innerHTML = `
        <div class="fixed bottom-6 right-6 z-[999999] w-80 bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-red-200 overflow-hidden font-sans p-4 text-red-500 text-sm">
          Failed to fetch arbitrage data.
        </div>
      `;
      return;
    }

    const { sku, prices, fees, condition, settings, isGoatLive } = data;
    this.currentData = data;

    // Calculate best platform
    let bestPlatform = '';
    let maxPayout = 0;

    if (condition === 'new') {
        if (fees.stockx > maxPayout) { maxPayout = fees.stockx; bestPlatform = 'stockx'; }
        if (fees.goat > maxPayout) { maxPayout = fees.goat; bestPlatform = 'goat'; }
        if (fees.kickscrew > maxPayout) { maxPayout = fees.kickscrew; bestPlatform = 'kickscrew'; }
    } else {
        if (fees.goat > maxPayout) { maxPayout = fees.goat; bestPlatform = 'goat'; }
    }

    // Target ROI Math
    const roiMultiplier = 1 + ((settings.targetRoi || 20) / 100);
    const maxBuyPrice = maxPayout / roiMultiplier;

    // Render Minimized Pill
    if (this.isMinimized) {
      this.uiWrapper.innerHTML = `
        <div id="btn-maximize" class="fixed bottom-6 right-6 z-[999999] bg-slate-900 hover:bg-slate-800 text-white px-4 py-2.5 rounded-full shadow-2xl border border-slate-700 font-sans flex items-center gap-2.5 cursor-pointer transition-all duration-200 hover:scale-105 select-none">
          <span class="text-base">👟</span>
          <div class="flex flex-col">
            <span class="text-[10px] text-slate-400 font-bold uppercase tracking-wider leading-none">Max Buy</span>
            <span class="text-xs font-black text-emerald-400 leading-tight">$${maxBuyPrice.toFixed(2)}</span>
          </div>
          <span class="text-xs text-slate-400 hover:text-white pl-1">▲</span>
        </div>
      `;
      const maxBtn = this.shadow.getElementById('btn-maximize');
      if (maxBtn) {
        maxBtn.addEventListener('click', () => {
          this.isMinimized = false;
          this.renderData(data);
        });
      }
      return;
    }

    // Render Full Expanded Card
    this.uiWrapper.innerHTML = `
      <div class="fixed bottom-6 right-6 z-[999999] w-[340px] bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden font-sans transition-all duration-200">
        
        <!-- Header -->
        <div class="p-3 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
          <div class="flex items-center gap-2">
            <span class="text-lg">👟</span>
            <div>
              <h3 class="font-bold text-sm text-slate-800 dark:text-white leading-tight">SneakerMargin</h3>
              <p class="text-[10px] text-slate-500 font-mono uppercase tracking-wider">SKU: ${sku}</p>
            </div>
          </div>
          <div class="flex items-center gap-2">
            ${this.renderToggle()}
            <!-- Minimize Button -->
            <button class="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 p-1 transition-colors" id="min-btn" title="Minimize">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M19 12H5"></path></svg>
            </button>
            <!-- Close Button -->
            <button class="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 p-1 transition-colors" id="close-btn" title="Close">
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
          </div>
        </div>

        <!-- Body -->
        <div class="p-4 space-y-3">
          
          <!-- Velocity Banner -->
          ${this.salesVelocity ? `<div class="bg-orange-50 text-orange-700 text-xs font-bold px-3 py-1.5 rounded-lg border border-orange-100 flex items-center gap-1.5 shadow-sm">🔥 ${this.salesVelocity}</div>` : ''}

          <!-- Best Sell Option -->
          <div class="bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-800/30 rounded-lg p-3 relative">
            <div class="flex justify-between items-start mb-2 border-b border-indigo-200/50 pb-2">
              <div>
                <p class="text-[10px] text-indigo-500 font-bold uppercase tracking-wide">Max Buy Price</p>
                <div class="flex items-baseline gap-1">
                  <span class="text-xl font-black text-slate-900 dark:text-white">$${maxBuyPrice.toFixed(2)}</span>
                  <span class="text-[10px] text-slate-500 font-medium">for ${settings.targetRoi || 20}% ROI</span>
                </div>
              </div>
              <div class="text-right">
                <p class="text-[10px] text-indigo-500 font-bold uppercase tracking-wide">Best Payout</p>
                <span class="text-xl font-black text-emerald-600">$${maxPayout.toFixed(2)}</span>
                <p class="text-[10px] font-bold text-slate-500 capitalize leading-none pt-0.5">via ${bestPlatform || 'N/A'}</p>
              </div>
            </div>
          </div>

          <!-- Breakdown -->
          <div class="space-y-1.5 pt-1">
            <div class="flex justify-between items-center px-1">
              <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Cross-Platform (USD)</span>
              <span class="text-[9px] font-semibold text-slate-400">${this.localCurrency === 'MXN' ? 'Auto-converted from MXN' : 'Live USD'}</span>
            </div>
            ${this.renderRow('StockX', prices.stockx, fees.stockx, condition === 'used', `https://stockx.com/search?s=${encodeURIComponent(sku)}`, true)}
            ${this.renderRow('GOAT', prices.goat, fees.goat, false, `https://www.goat.com/search?query=${encodeURIComponent(sku)}`, isGoatLive)}
            ${this.renderRow('Kickscrew', prices.kickscrew, fees.kickscrew, condition === 'used', `https://www.kickscrew.com/search?q=${encodeURIComponent(sku)}`, window.location.hostname.includes('kickscrew.com'))}
          </div>

          <!-- Discord Webhook -->
          ${settings.discordWebhook ? `
          <button id="btn-discord" class="w-full mt-2 bg-[#5865F2] hover:bg-[#4752C4] text-white text-xs font-bold py-2 px-3 rounded-lg shadow-sm flex justify-center items-center gap-2 transition-colors">
            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286z"/></svg>
            Post to Cook Group
          </button>
          ` : `<p class="text-[10px] text-center text-slate-400 mt-2">Add Discord Webhook in Extension Settings</p>`}

          <!-- Support & Feedback Link -->
          <div class="pt-1 text-center">
            <a href="https://mail.google.com/mail/?view=cm&fs=1&to=ayesua@gmail.com&su=SneakerMargin%20Feedback%20(SKU:%20${encodeURIComponent(sku)})" target="_blank" class="text-[10px] text-slate-400 hover:text-indigo-500 font-medium transition-colors no-underline">
              Need Help? Send Feedback (ayesua@gmail.com)
            </a>
          </div>

        </div>
      </div>
    `;

    this.shadow.getElementById('close-btn').addEventListener('click', () => {
      this.uiWrapper.innerHTML = '';
    });

    this.shadow.getElementById('min-btn').addEventListener('click', () => {
      this.isMinimized = true;
      this.renderData(data);
    });

    this.attachToggleListener();

    const btnDiscord = this.shadow.getElementById('btn-discord');
    if (btnDiscord) {
        btnDiscord.addEventListener('click', () => this.postToDiscord(maxBuyPrice, maxPayout, bestPlatform));
    }
  }

  renderToggle() {
    const isUsed = this.currentCondition === 'used';
    return `
      <div class="flex items-center gap-1.5">
        <span class="text-[9px] font-bold uppercase tracking-wider ${!isUsed ? 'text-indigo-600' : 'text-slate-400'}">New</span>
        <label class="relative inline-flex items-center cursor-pointer">
          <input type="checkbox" id="condition-toggle" class="sr-only peer" ${isUsed ? 'checked' : ''}>
          <div class="w-6 h-3 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[1px] after:left-[1px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-2.5 after:w-2.5 after:transition-all peer-checked:bg-indigo-600"></div>
        </label>
        <span class="text-[9px] font-bold uppercase tracking-wider ${isUsed ? 'text-indigo-600' : 'text-slate-400'}">Used</span>
      </div>
    `;
  }

  attachToggleListener() {
    const toggle = this.shadow.getElementById('condition-toggle');
    if (toggle) {
      toggle.addEventListener('change', (e) => {
        this.currentCondition = e.target.checked ? 'used' : 'new';
        this.fetchAndRender();
      });
    }
  }

  renderRow(name, ask, payout, disabled, url, isLive) {
    if (disabled) {
      return `
        <div class="flex justify-between items-center p-2 rounded bg-slate-50 dark:bg-slate-800/20 opacity-50 select-none">
          <span class="text-sm font-semibold text-slate-400 line-through">${name}</span>
          <div class="text-right">
            <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wide bg-slate-200 dark:bg-slate-700 px-1.5 py-0.5 rounded">Deadstock Only</div>
          </div>
        </div>
      `;
    }

    return `
      <a href="${url}" target="_blank" class="flex justify-between items-center p-2 rounded hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer group no-underline">
        <div class="flex items-center gap-1.5">
          <span class="text-sm font-semibold text-slate-700 dark:text-slate-300 group-hover:text-indigo-600 transition-colors">${name}</span>
          <span class="w-1.5 h-1.5 rounded-full ${isLive ? 'bg-emerald-500' : 'bg-amber-400'}" title="${isLive ? 'Live Platform Data' : 'Estimated Valuation'}"></span>
          <svg class="w-3 h-3 text-slate-300 group-hover:text-indigo-400 opacity-0 group-hover:opacity-100 transition-opacity" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>
        </div>
        <div class="text-right">
          <div class="text-sm font-bold text-slate-900 dark:text-white">Ask: $${ask ? ask.toFixed(2) : 'N/A'}</div>
          <div class="text-xs text-slate-500">Payout: $${payout ? payout.toFixed(2) : '0.00'}</div>
        </div>
      </a>
    `;
  }

  async postToDiscord(maxBuyPrice, maxPayout, bestPlatform) {
      const btn = this.shadow.getElementById('btn-discord');
      const originalText = btn.innerHTML;
      btn.innerHTML = `<div class="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>`;

      try {
          const payload = {
              username: "SneakerMargin Engine",
              avatar_url: "https://i.imgur.com/8QzX9n1.png",
              embeds: [{
                  title: `🔥 Arbitrage Alert: ${this.currentSku}`,
                  color: 5814783,
                  fields: [
                      { name: "Best Payout", value: `$${maxPayout.toFixed(2)} (${bestPlatform})`, inline: true },
                      { name: `Max Buy Price (${this.currentData.settings.targetRoi || 20}% ROI)`, value: `$${maxBuyPrice.toFixed(2)}`, inline: true },
                      { name: "Condition", value: this.currentCondition.toUpperCase(), inline: true }
                  ],
                  footer: { text: "Generated by SneakerMargin Calculator" },
                  timestamp: new Date().toISOString()
              }]
          };

          const res = await fetch(this.currentData.settings.discordWebhook, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(payload)
          });

          if (!res.ok) throw new Error("Discord Rejected Request");

          btn.innerHTML = `✅ Posted!`;
          btn.classList.replace('bg-[#5865F2]', 'bg-emerald-500');
          setTimeout(() => {
              btn.innerHTML = originalText;
              btn.classList.replace('bg-emerald-500', 'bg-[#5865F2]');
          }, 3000);

      } catch (err) {
          console.error(err);
          btn.innerHTML = `❌ Failed`;
          btn.classList.replace('bg-[#5865F2]', 'bg-red-500');
          setTimeout(() => {
              btn.innerHTML = originalText;
              btn.classList.replace('bg-red-500', 'bg-[#5865F2]');
          }, 3000);
      }
  }
}

function extractSKU() {
  const host = window.location.hostname;
  let sku = null;

  if (host.includes('stockx.com')) {
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

    // Strategy 1: SEO Structured Data
    try {
      const scripts = document.querySelectorAll('script[type="application/ld+json"]');
      for (const script of scripts) {
        const data = JSON.parse(script.innerText);
        let potentialSku = null;
        if (data.sku) potentialSku = data.sku;
        else if (data['@graph']) {
           const product = data['@graph'].find(item => item['@type'] === 'Product' || item.sku);
           if (product && product.sku) potentialSku = product.sku;
        }
        
        if (potentialSku && !uuidRegex.test(potentialSku)) {
            sku = potentialSku;
            break;
        }
      }
    } catch(e) {}

    // Strategy 2: DOM search for "Style"
    if (!sku) {
      try {
        const elements = Array.from(document.querySelectorAll('p, span')).filter(el => el.textContent.trim().toLowerCase() === 'style');
        if (elements.length > 0) {
          let nextEl = elements[0].nextElementSibling;
          if (!nextEl && elements[0].parentElement) {
            nextEl = elements[0].parentElement.nextElementSibling;
          }
          if (nextEl) {
            sku = nextEl.textContent.trim();
          }
        }
      } catch(e) {}
    }

    // Strategy 3: URL Slug Fallback
    if (!sku) {
        const pathSegments = window.location.pathname.split('/').filter(p => p.length > 0);
        const slug = pathSegments[pathSegments.length - 1]; 
        if (slug) {
            sku = slug.replace(/-/g, ' '); 
        } else {
            sku = 'DZ5485-612'; 
        }
    }

  } else if (host.includes('goat.com')) {
    // Strategy 1: SEO JSON-LD on GOAT
    try {
      const scripts = document.querySelectorAll('script[type="application/ld+json"]');
      for (const script of scripts) {
        const data = JSON.parse(script.innerText);
        if (data.sku && !data.sku.includes('{')) {
          sku = data.sku;
          break;
        } else if (data.model) {
          sku = data.model;
          break;
        }
      }
    } catch(e) {}

    // Strategy 2: Extract SKU from GOAT URL (e.g. /sneakers/shoe-name-308497-104 or /sneakers/shoe-bb1826)
    if (!sku) {
      const urlParts = window.location.pathname.split('-');
      if (urlParts.length >= 2) {
        const possibleTwoPart = urlParts.slice(-2).join('-');
        if (possibleTwoPart.match(/^[a-z0-9]{4,8}-[a-z0-9]{3,4}$/i)) {
          sku = possibleTwoPart;
        } else {
          const lastPart = urlParts[urlParts.length - 1];
          if (lastPart.match(/^[a-z0-9]{5,9}$/i)) {
            sku = lastPart;
          }
        }
      }
    }

    // Strategy 3: Fallback to URL slug
    if (!sku) {
      const pathSegments = window.location.pathname.split('/').filter(p => p.length > 0);
      const slug = pathSegments[pathSegments.length - 1];
      if (slug) sku = slug.replace(/-/g, ' ');
    }

  } else if (host.includes('kickscrew.com')) {
    const urlParts = window.location.pathname.split('-');
    if (urlParts.length > 2) {
        const possibleSku = urlParts.slice(-2).join('-');
        if (possibleSku.match(/^[a-z0-9]{4,8}-[a-z0-9]{3,4}$/i)) {
            sku = possibleSku;
        } else {
            sku = urlParts[urlParts.length - 1];
        }
    } else {
        sku = 'KICK-SKU-MOCK';
    }
  }

  return (sku || 'DZ5485-612').toUpperCase();
}

/**
 * Hardened price extractor: ranks candidates by computed font size & visibility,
 * and filters out promo banners, coupon codes, and financing installment labels.
 */
function extractLocalPrice() {
    const host = window.location.hostname;
    let price = null;

    if (host.includes('stockx.com') || host.includes('kickscrew.com') || host.includes('goat.com')) {
        try {
            const forbiddenWords = ['off', 'save', 'spend', 'month', 'mo', 'fee', 'free', 'discount', 'order', 'credit', 'gift', 'reveal', 'card', 'ship'];
            const elements = Array.from(document.querySelectorAll('body *:not(script):not(style):not(noscript):not(meta):not(link)'))
                .filter(el => {
                    const text = el.textContent.trim();
                    if (!text || text.length > 20) return false;
                    const lower = text.toLowerCase();
                    if (forbiddenWords.some(w => lower.includes(w))) return false;
                    return text.match(/^([A-Z]{1,3}\s?)?\$?[\d,]+(\.\d{2})?$/i);
                });
            
            if (elements.length > 0) {
                let bestCandidate = elements[0];
                let maxFontSize = 0;

                for (const el of elements) {
                    const style = window.getComputedStyle(el);
                    const fontSize = parseFloat(style.fontSize) || 12;
                    const isVisible = style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0';
                    if (isVisible && fontSize > maxFontSize) {
                        maxFontSize = fontSize;
                        bestCandidate = el;
                    }
                }

                const text = bestCandidate.textContent.trim();
                const numericStr = text.replace(/[^\d\.]/g, ''); 
                const parsed = parseFloat(numericStr);
                if (!isNaN(parsed) && parsed > 15 && parsed < 250000) price = parsed;
            }
        } catch(e) {}
    }
    return price;
}

function extractVelocity() {
    const host = window.location.hostname;
    if (host.includes('stockx.com')) {
        try {
            const elements = Array.from(document.querySelectorAll('body *:not(script):not(style):not(noscript)')).filter(el => {
                const text = el.textContent.trim().toLowerCase();
                return text.includes('sold in last') && text.length < 100;
            });
            
            if (elements.length > 0) {
                const exactMatch = elements.reduce((a, b) => a.textContent.length <= b.textContent.length ? a : b);
                return exactMatch.textContent.trim();
            }
        } catch(e) {}
    }
    return null;
}

function extractCurrency() {
    const host = window.location.hostname;
    const path = window.location.pathname.toLowerCase();

    // 1. GOAT is always USD
    if (host.includes('goat.com')) return 'USD';

    // 2. Check URL path patterns (e.g. /en-mx, /es-mx)
    if (path.includes('/en-mx') || path.includes('/es-mx') || path.includes('/mx/')) return 'MXN';

    // 3. Scan DOM for explicit MXN / MX$ text
    try {
        const bodyText = document.body.innerText || '';
        if (bodyText.includes('MX$') || bodyText.includes('MXN')) return 'MXN';
    } catch(e) {}

    // 4. Heuristic on StockX: if scraped local price > 1200 on non-hyped shoe, it's MXN
    return 'USD';
}

// Initialization & SPA Watcher
let uiInstance = null;
let lastUrl = window.location.href;

function init() {
  uiInstance = new ArbitrageUI();
  uiInstance.fetchAndRender();

  // Poll for SPA navigations and DOM price changes (e.g. Size/Color selection)
  setInterval(() => {
      const newPrice = extractLocalPrice();
      const newCurrency = extractCurrency();
      if (window.location.href !== lastUrl || (newPrice && newPrice !== uiInstance.localPrice)) {
          lastUrl = window.location.href;
          uiInstance.currentSku = extractSKU();
          uiInstance.localPrice = newPrice;
          uiInstance.localCurrency = newCurrency;
          uiInstance.salesVelocity = extractVelocity();
          uiInstance.fetchAndRender();
      }
  }, 1000);
}

setTimeout(init, 1500);
