/**
 * SneakerMargin - Popup Script (PayPal & License System)
 */

document.addEventListener('DOMContentLoaded', () => {
    // License UI Elements
    const elActive = document.getElementById('license-active');
    const elUnpaid = document.getElementById('license-unpaid');
    const inputLicenseKey = document.getElementById('input-license-key');
    const btnActivate = document.getElementById('btn-activate');
    const licenseError = document.getElementById('license-error');

    // Preferences UI Elements
    const inputRoi = document.getElementById('input-roi');
    const selectStockxLevel = document.getElementById('select-stockx-level');
    const selectGoatFee = document.getElementById('select-goat-fee');
    const inputExchange = document.getElementById('input-exchange');
    const inputWebhook = document.getElementById('input-webhook');
    const btnSave = document.getElementById('btn-save');

    // 1. Check License Status from Storage
    chrome.storage.local.get({
        isPro: false,
        licenseKey: '',
        targetRoi: 20,
        stockxLevel: '1',
        goatFee: '9.5',
        exchangeRate: 19.5,
        discordWebhook: ''
    }, (data) => {
        if (data.isPro) {
            elActive.classList.remove('hidden');
            elUnpaid.classList.add('hidden');
        } else {
            elUnpaid.classList.remove('hidden');
            elActive.classList.add('hidden');
        }

        inputRoi.value = data.targetRoi;
        selectStockxLevel.value = data.stockxLevel;
        selectGoatFee.value = data.goatFee;
        inputExchange.value = data.exchangeRate;
        inputWebhook.value = data.discordWebhook;
    });

    // 2. License Activation Handler
    btnActivate.addEventListener('click', () => {
        const enteredKey = (inputLicenseKey.value || '').trim().toUpperCase();
        
        // Accept valid license key formats (e.g. SNKR-XXXX-XXXX or VIP codes)
        if (isValidLicenseKey(enteredKey)) {
            chrome.storage.local.set({ isPro: true, licenseKey: enteredKey }, () => {
                licenseError.classList.add('hidden');
                elUnpaid.classList.add('hidden');
                elActive.classList.remove('hidden');
            });
        } else {
            licenseError.classList.remove('hidden');
            inputLicenseKey.classList.add('border-red-400');
            setTimeout(() => {
                inputLicenseKey.classList.remove('border-red-400');
            }, 2500);
        }
    });

    // 3. Save Preferences
    btnSave.addEventListener('click', () => {
        const targetRoi = parseInt(inputRoi.value, 10) || 20;
        const stockxLevel = selectStockxLevel.value;
        const goatFee = selectGoatFee.value;
        const exchangeRate = parseFloat(inputExchange.value) || 19.5;
        const discordWebhook = inputWebhook.value.trim();

        chrome.storage.local.set({
            targetRoi,
            stockxLevel,
            goatFee,
            exchangeRate,
            discordWebhook
        }, () => {
            btnSave.innerText = 'Saved!';
            btnSave.classList.replace('bg-slate-800', 'bg-emerald-600');
            setTimeout(() => {
                btnSave.innerText = 'Save Preferences';
                btnSave.classList.replace('bg-emerald-600', 'bg-slate-800');
            }, 1500);
        });
    });
});

/**
 * Validates buyer activation keys
 * Accepts keys formatted like: SNKR-XXXX-XXXX or SNKR-2026-VIP or PRO-XXXX
 */
function isValidLicenseKey(key) {
    if (!key || key.length < 8) return false;
    if (key === 'SNKR-2026-VIP' || key === 'VIP-LIFETIME' || key === 'SNKR-PRO-2026') return true;
    return key.startsWith('SNKR-') || key.startsWith('PRO-');
}
